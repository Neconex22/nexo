# Contenido: YouTube, TikTok, streaming

## ideas-videos
claves: ideas, ideas de videos, que subo, contenido, viral
- Da ideas concretas con título, gancho y por qué funcionaría. Mezcla formatos: reto, tutorial, reacción, top, historia.
- Piensa en el nicho del creador (gaming: Fortnite, Roblox, Valorant) y en tendencias que se puedan grabar ya.

## titulos-youtube
claves: titulo youtube, titulo, clickbait, nombre del video
- 40-60 caracteres, palabra clave al principio, curiosidad o beneficio claro. Mayúsculas solo en 1-2 palabras.
- Da 5 opciones de estilos distintos. Sin mentir sobre el contenido.

## miniaturas
claves: miniatura, thumbnail, portada del video
- Máximo 3 elementos: cara/personaje con emoción, objeto clave y 2-4 palabras grandes.
- Alto contraste, legible en pequeño, colores que destaquen frente a YouTube (amarillo, rojo, cian).
- Puedes generarla con ffmpeg (frame + drawtext) o como HTML/SVG exportable.

## guion-tiktok
claves: tiktok, guion tiktok, short, reel, video corto
- Gancho 0-2 s (pregunta, afirmación chocante o resultado final primero).
- Desarrollo rápido con cortes cada 2-3 s. Final con giro o llamada a comentar.
- Indica en el guion qué se ve (plano) y qué se dice/escribe.

## descripcion-seo-youtube
claves: descripcion youtube, tags, etiquetas, seo youtube
- Primeras 2 líneas con la palabra clave y el gancho. Capítulos con marcas de tiempo (00:00 Intro).
- Enlaces a redes y 3 hashtags al final.

## directo-streaming
claves: directo, stream, twitch, obs, streaming, en vivo
- Título del directo con plan concreto ("Ranked hasta Unreal 🔥 !reto"). Escenas: Inicio, Juego, Pausa, Final.
- Ideas de interacción: comandos de chat, retos por suscripción, encuestas, objetivos de seguidores.

## edicion-ritmo
claves: ritmo, edicion dinamica, cortes, retencion, aburrido
- Quita silencios y respiraciones largas, corta cada vez que baja la energía.
- Zoom en momentos clave, texto en pantalla para frases importantes, efectos de sonido puntuales.
- Gancho al principio aunque sea un avance del mejor momento.

## calendario-contenido
claves: calendario, planificar, horario, cuando subir, constancia
- Tabla semanal con día, plataforma, formato e idea. Realista con el tiempo disponible.
- Reutiliza: directo → clips → shorts/TikToks.

## analizar-estadisticas
claves: estadisticas, analiticas, views, retencion, crecer, suscriptores
- Pide los datos (CTR, retención, vistas por vídeo). Compara con la media del canal, no con otros.
- Da 3 acciones concretas priorizadas.

## marca-personal
claves: marca, branding, logo canal, banner, estilo del canal
- Define 2-3 colores, 1-2 fuentes y un tono. Úsalos en miniaturas, overlays y banners para ser reconocible.
- Banner YouTube 2560x1440 (zona segura central 1546x423). Avatar legible a 48 px.
