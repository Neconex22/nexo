// Actualizaciones automáticas: las copias instaladas miran la web de Nexo y se actualizan solas.
// En la web hay version.json {"version":"..."} y actualizacion.zip (la app sin modelos ni datos).
// La copia del propietario (la original) NO se actualiza sola.
import fs from 'node:fs/promises';
import path from 'node:path';
import os from 'node:os';
import { spawn } from 'node:child_process';

export const WEB = process.env.NEXO_WEB || 'https://neconex22.github.io/nexo/';
const NO_TOCAR = new Set(['data', 'models', 'ollama', 'trabajos', 'cache', 'tools', 'Nexo.exe']);

export function crearActualizador(ROOT, APP) {
  const estado = { local: null, remota: null, actualizado: null, error: null, comprobando: false };
  async function versionLocal() { return (await fs.readFile(path.join(APP, 'version.txt'), 'utf8').catch(() => '0')).trim(); }
  const num = v => String(v).split('.').map(x => parseInt(x, 10) || 0);
  const mayor = (a, b) => { const x = num(a), y = num(b); for (let i = 0; i < Math.max(x.length, y.length); i++) { if ((x[i] || 0) !== (y[i] || 0)) return (x[i] || 0) > (y[i] || 0); } return false; };

  async function copiar(src, dst, raiz = true) {
    for (const it of await fs.readdir(src, { withFileTypes: true })) {
      if (raiz && NO_TOCAR.has(it.name)) continue;
      const a = path.join(src, it.name), b = path.join(dst, it.name);
      if (it.isDirectory()) { await fs.mkdir(b, { recursive: true }); await copiar(a, b, false); }
      else { try { await fs.copyFile(a, b); } catch { /* archivo en uso: se queda el anterior */ } }
    }
  }

  // Comprueba y, si hay versión nueva, la instala y reinicia el servidor
  async function comprobar(onReinicio) {
    if (estado.comprobando) return estado; estado.comprobando = true;
    try {
      estado.local = await versionLocal();
      const r = await fetch(WEB + 'version.json?t=' + Date.now(), { signal: AbortSignal.timeout(10000) });
      if (!r.ok) throw new Error('web no disponible (' + r.status + ')');
      const info = await r.json(); estado.remota = info.version;
      if (!mayor(info.version, estado.local)) return estado;
      console.log(`[Nexo] Actualizando ${estado.local} → ${info.version}…`);
      const tmp = path.join(os.tmpdir(), 'nexo-act-' + Date.now()); await fs.mkdir(tmp, { recursive: true });
      const zip = path.join(tmp, 'act.zip');
      const z = await fetch(WEB + (info.zip || 'actualizacion.zip') + '?v=' + info.version, { signal: AbortSignal.timeout(120000) });
      if (!z.ok) throw new Error('no se pudo descargar la actualización');
      await fs.writeFile(zip, Buffer.from(await z.arrayBuffer()));
      await new Promise((res, rej) => { const p = spawn('tar', ['-xf', zip, '-C', tmp], { windowsHide: true }); p.on('close', c => c === 0 ? res() : rej(new Error('zip dañado'))); p.on('error', rej); });
      const src = (await fs.stat(path.join(tmp, 'Nexo')).catch(() => null)) ? path.join(tmp, 'Nexo') : tmp;
      await copiar(src, ROOT);
      await fs.writeFile(path.join(APP, 'version.txt'), info.version, 'utf8');
      await fs.rm(tmp, { recursive: true, force: true }).catch(() => {});
      estado.actualizado = info.version;
      console.log('[Nexo] Actualizado a ' + info.version + '. Reiniciando…');
      onReinicio?.();
    } catch (e) { estado.error = String(e.message || e); }
    finally { estado.comprobando = false; }
    return estado;
  }
  return { estado, comprobar, versionLocal };
}

// Reinicia este mismo servidor (el nuevo espera a que el puerto quede libre)
export function reiniciarServidor(script) {
  spawn(process.execPath, [script], { detached: true, stdio: 'ignore', windowsHide: true, cwd: path.dirname(path.dirname(script)) }).unref();
  setTimeout(() => process.exit(0), 300);
}
