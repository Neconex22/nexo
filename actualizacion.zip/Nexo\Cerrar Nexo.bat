@echo off
echo Cerrando Nexo y liberando la grafica...
powershell -NoProfile -Command "$n='%~dp0'; Get-CimInstance Win32_Process | Where-Object { $_.ExecutablePath -like ($n + '*') -or $_.CommandLine -like ('*' + $n + '*') } | ForEach-Object { Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue }"
echo Listo.
timeout /t 2 >nul
