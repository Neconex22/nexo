# Vídeo y audio (ffmpeg)

## video-basico
claves: video, editar, edita, montar, monta, mp4, clip
Reglas de ffmpeg en PowerShell:
- Siempre `-y`, rutas entre comillas dobles, filtros (-vf/-filter_complex) entre comillas dobles.
- Antes de editar, mira el vídeo: `ffprobe -v error -show_entries format=duration:stream=width,height,r_frame_rate -of json "in.mp4"`.
- Codificación final compatible: `-c:v libx264 -preset medium -crf 20 -pix_fmt yuv420p -c:a aac -b:a 160k -movflags +faststart`.
- Con GPU NVIDIA, más rápido: `-c:v h264_nvenc -preset p5 -cq 21`.
- Al terminar, comprueba que el archivo existe (listar) y ábrelo.

## video-recortar
claves: recortar, cortar, trim, quitar el principio, del segundo
- Corte rápido sin recodificar: `ffmpeg -y -ss 00:01:10 -to 00:01:40 -i "in.mp4" -c copy "corte.mp4"` (puede no ser exacto al fotograma).
- Corte exacto: pon `-ss` después de `-i` y recodifica con libx264.
- Varios cortes: genera cada trozo y luego únelos (video-unir).

## video-unir
claves: unir, juntar, concatenar, montaje, varios clips
- Mismo formato: crea `lista.txt` con líneas `file 'C:/ruta/clip1.mp4'` y ejecuta `ffmpeg -y -f concat -safe 0 -i lista.txt -c copy "unido.mp4"`.
- Formatos distintos: normaliza antes cada clip a la misma resolución, fps (60) y audio (48000 Hz) o usa filtro concat: `-filter_complex "[0:v][0:a][1:v][1:a]concat=n=2:v=1:a=1[v][a]" -map "[v]" -map "[a]"`.

## video-vertical
claves: vertical, tiktok, shorts, reels, 9:16, 1080x1920
- Recorte centrado: `-vf "scale=1080:1920:force_original_aspect_ratio=increase,crop=1080:1920"`.
- Con fondo desenfocado (sin recortar): `-filter_complex "[0:v]scale=1080:1920:force_original_aspect_ratio=increase,crop=1080:1920,boxblur=20:5[bg];[0:v]scale=1080:-2[fg];[bg][fg]overlay=(W-w)/2:(H-h)/2" -c:a copy`.
- Límite habitual: TikTok hasta 10 min, Shorts hasta 3 min.

## video-texto-subtitulos
claves: texto, subtitulos, titulo, letras, poner texto, captions
- Texto: `drawtext=text='TEXTO':fontfile='C\:/Windows/Fonts/arialbd.ttf':fontsize=90:fontcolor=white:borderw=6:bordercolor=black:x=(w-text_w)/2:y=h*0.75`.
- Texto solo entre segundos: añade `:enable='between(t,2,5)'`.
- Subtítulos desde .srt: `-vf "subtitles=subs.srt:force_style='Fontsize=22,Outline=2,Alignment=2'"` (ruta del srt sin unidad o escapada).
- Escribe el .srt con escribir_archivo (formato: número, `00:00:01,000 --> 00:00:03,000`, texto, línea en blanco).

## subtitulos-automaticos
claves: subtitulos automaticos, subtitula, transcribe, transcripcion, que dice, lo que digo, voz a texto, captions, resumen del video, momentos
- Usa la herramienta `transcribir` con el vídeo: crea `nombre.srt` y `nombre.txt` al lado.
- Para quemar los subtítulos en el vídeo (ffmpeg, en la carpeta del vídeo para usar ruta relativa del srt):
  `ffmpeg -y -i "video.mp4" -vf "subtitles=video.srt:force_style='FontName=Arial,Fontsize=18,Bold=1,Outline=2,Alignment=2,MarginV=40'" -c:a copy "video-subtitulado.mp4"`
- Estilo TikTok (grandes y en el centro): Fontsize=26, Alignment=10.
- Para resumir o buscar momentos, lee el .txt/.srt y usa los tiempos del .srt para cortar.

## video-velocidad-efectos
claves: camara lenta, acelerar, velocidad, zoom, fundido, fade, efecto
- Acelerar x2: `-filter_complex "[0:v]setpts=0.5*PTS[v];[0:a]atempo=2.0[a]" -map "[v]" -map "[a]"`. Cámara lenta x0.5: setpts=2*PTS y atempo=0.5.
- Fundido: `-vf "fade=t=in:st=0:d=0.5,fade=t=out:st=9.5:d=0.5"`.
- Zoom suave: `-vf "zoompan=z='min(zoom+0.0015,1.3)':d=1:s=1920x1080:fps=60"`.

## audio-edicion
claves: audio, musica, sonido, mp3, volumen, quitar audio, voz
- Extraer audio: `ffmpeg -y -i "in.mp4" -vn -c:a libmp3lame -q:a 2 "audio.mp3"`.
- Quitar audio: `-an`. Cambiar volumen: `-af "volume=1.5"`. Normalizar: `-af loudnorm`.
- Música de fondo bajita bajo la voz: `-filter_complex "[1:a]volume=0.15[m];[0:a][m]amix=inputs=2:duration=first[a]" -map 0:v -map "[a]" -c:v copy`.

## video-miniatura-gif
claves: miniatura, thumbnail, captura, frame, gif, imagen del video
- Captura un fotograma: `ffmpeg -y -ss 00:00:05 -i "in.mp4" -frames:v 1 "frame.png"`.
- GIF bueno: `-vf "fps=15,scale=480:-1:flags=lanczos,split[a][b];[a]palettegen[p];[b][p]paletteuse" "out.gif"`.
- Miniatura de YouTube 1280x720 con texto: escala el frame y añade drawtext grande con borde.

## video-comprimir
claves: comprimir, pesa mucho, reducir tamaño, 10 mb, menos peso, discord
- Calidad/tamaño: sube CRF (23-28) o baja resolución `-vf scale=-2:720`.
- Tamaño objetivo: bitrate (kbps) = tamaño_MB × 8192 / duración_s − 128 (audio). Usa `-b:v XXXk -maxrate XXXk -bufsize 2XXXk`.
- Para Discord/TikTok desde el navegador: menos de 10 MB.

## video-desde-imagenes
claves: slideshow, fotos a video, imagenes, presentacion en video, intro
- Secuencia: `ffmpeg -y -framerate 1/3 -i "img%03d.png" -c:v libx264 -r 30 -pix_fmt yuv420p "slides.mp4"`.
- Una imagen + audio: `ffmpeg -y -loop 1 -i "foto.png" -i "audio.mp3" -c:v libx264 -tune stillimage -c:a aac -shortest -pix_fmt yuv420p "out.mp4"`.
- Intro con color y texto: `-f lavfi -i color=c=0x0d0f14:s=1920x1080:d=3` + drawtext + fade.
