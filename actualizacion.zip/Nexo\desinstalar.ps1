﻿# Desinstala Nexo: cierra lo que esté abierto, quita accesos directos y borra la carpeta de Nexo.
Add-Type -AssemblyName System.Windows.Forms
$N = $PSScriptRoot
$r = [System.Windows.Forms.MessageBox]::Show("¿Seguro que quieres desinstalar Nexo?`n`nSe borrarán la app, los modelos de IA, tus chats y lo que haya creado Nexo en:`n$N", "Desinstalar Nexo", "YesNo", "Warning")
if ($r -ne "Yes") { exit }
Get-CimInstance Win32_Process | Where-Object { $_.ExecutablePath -like "$N*" -or $_.CommandLine -like "*$N*" } | ForEach-Object { Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue }
Start-Sleep 2
Remove-Item "$([Environment]::GetFolderPath('Programs'))\Nexo" -Recurse -Force -ErrorAction SilentlyContinue
Remove-Item "$([Environment]::GetFolderPath('DesktopDirectory'))\Nexo.lnk" -Force -ErrorAction SilentlyContinue
Remove-Item "HKCU:\Software\Microsoft\Windows\CurrentVersion\Uninstall\Nexo" -Recurse -Force -ErrorAction SilentlyContinue
Set-Location $env:TEMP
Remove-Item $N -Recurse -Force -ErrorAction SilentlyContinue
[System.Windows.Forms.MessageBox]::Show("Nexo se ha desinstalado.", "Nexo") | Out-Null
