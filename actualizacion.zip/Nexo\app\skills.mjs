// Skills de Nexo: archivos .md en nexo/skills. Cada "## nombre" es una skill con una linea "claves:".
import fs from 'node:fs/promises';
import path from 'node:path';

export const norm = s => String(s || '').toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '');

export async function loadSkills(dir) {
  const files = (await fs.readdir(dir).catch(() => [])).filter(f => f.endsWith('.md')).sort();
  const skills = [];
  for (const f of files) {
    const txt = await fs.readFile(path.join(dir, f), 'utf8');
    const cat = (txt.match(/^#\s+(.+)$/m) || [])[1] || f.replace(/\.md$/, '');
    for (const block of txt.split(/^##\s+/m).slice(1)) {
      const lines = block.split(/\r?\n/);
      const name = lines[0].trim();
      const kl = lines.findIndex(l => /^claves:/i.test(l));
      const claves = kl >= 0 ? lines[kl].replace(/^claves:/i, '').split(',').map(s => norm(s.trim())).filter(Boolean) : [];
      const body = lines.slice(1).filter((_, i) => i + 1 !== kl).join('\n').trim();
      if (name) skills.push({ name, cat, file: f, claves, body });
    }
  }
  return skills;
}

// Elige las skills mas relevantes para el texto del usuario
export function pickSkills(skills, text, off = [], max = 3) {
  const t = ' ' + norm(text).replace(/[^a-z0-9.#+ ]/g, ' ').replace(/\s+/g, ' ') + ' ';
  const scored = [];
  for (const s of skills) {
    if (off.includes(s.name)) continue;
    let score = 0;
    for (const k of s.claves) {
      if (!k) continue;
      const hit = k.length <= 3 ? t.includes(' ' + k + ' ') : t.includes(k);
      if (hit) score += 1 + k.split(' ').length * 0.5;
    }
    if (score > 0) scored.push({ s, score });
  }
  scored.sort((a, b) => b.score - a.score);
  return scored.slice(0, max).map(x => x.s);
}
