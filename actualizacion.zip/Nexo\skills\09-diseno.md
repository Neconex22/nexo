# Diseño gráfico

## svg-logos
claves: logo, logotipo, icono, svg, emblema
- Diseña en SVG (viewBox 0 0 512 512), formas simples, 2-3 colores, sin texto diminuto.
- Variante cuadrada para avatar. Exporta a PNG con Edge headless: `msedge --headless --screenshot="logo.png" --window-size=512,512 "logo.svg"` o con ffmpeg si está.

## paletas-color
claves: colores, paleta, combinar colores, color
- Paleta: primario, secundario/acento, 3-4 neutros. Da los códigos HEX.
- Contraste de texto mínimo 4.5:1. Modo oscuro: fondos #0f1115-#1a1d24, no negro puro.

## tipografia
claves: fuente, tipografia, letra, fonts
- Combinaciones seguras: sans para interfaz (Inter, Segoe UI), display con personalidad para títulos.
- Offline: usa fuentes del sistema (`system-ui, "Segoe UI"`) o incluye el archivo de fuente.

## overlay-obs
claves: overlay, obs, alertas, marco, webcam, escena
- HTML transparente (`background: transparent`) de 1920x1080 para Fuente de navegador de OBS.
- Marco de cámara, barra inferior con redes, animaciones suaves. Sin fondos que tapen el juego.

## banner-redes
claves: banner, cabecera, portada, twitter, youtube banner, twitch banner
- Tamaños: YouTube 2560x1440, Twitch 1200x480, X/Twitter 1500x500.
- Hazlo en HTML/SVG a tamaño exacto y captura con Edge headless `--screenshot --window-size=ANCHO,ALTO`.

## iconos-svg
claves: iconos, iconos svg, simbolos, botones con icono
- Iconos en línea con `<svg viewBox="0 0 24 24" stroke="currentColor" fill="none" stroke-width="2">`.
- Estilo coherente (todos de línea o todos rellenos). Nunca uses emojis como iconos en diseños profesionales.

## ilustracion-css
claves: ilustracion, dibujo, fondo, patron, decoracion
- Fondos con degradados radiales sutiles, ruido (SVG feTurbulence), formas blob en SVG.
- Patrones con `repeating-linear-gradient`. Evita los degradados genéricos morado-azul.

## ui-componentes
claves: boton, tarjeta, modal, menu, componente, interfaz
- Botón: padding 12px 20px, radio coherente, estados hover/active/focus/disabled.
- Tarjetas con borde sutil o sombra, nunca ambas fuertes. Modales con fondo oscurecido y cierre con ESC.

## imagen-editar
claves: imagen, foto, redimensionar, recortar imagen, convertir png, jpg
- ffmpeg sirve para imágenes: redimensionar `ffmpeg -y -i in.png -vf scale=1080:-1 out.png`; recortar `-vf crop=w:h:x:y`; convertir formato cambiando la extensión.
- Varias imágenes: bucle en PowerShell con Get-ChildItem.

## mockups
claves: mockup, boceto, wireframe, prototipo, maqueta
- Prototipo navegable en HTML con datos de ejemplo realistas. Primero estructura en gris, luego estilo.
