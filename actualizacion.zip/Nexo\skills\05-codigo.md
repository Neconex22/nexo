# Programación

## codigo-calidad
claves: codigo, programa, programar, script, funcion, app, aplicacion
- Entiende el objetivo antes de escribir. Escribe el archivo COMPLETO, nunca "...resto igual".
- Nombres claros, funciones cortas, sin código muerto. Comentarios solo donde algo no es obvio.
- Maneja errores de entrada/archivo/red con mensajes útiles.
- Después de crear un programa, EJECÚTALO con la herramienta ejecutar para comprobar que funciona y corrige errores.

## depurar
claves: error, bug, no funciona, falla, arregla, debug, excepcion
- Lee el mensaje de error completo y la línea. Reproduce el fallo antes de cambiar nada.
- Busca la causa raíz, no parches. Cambia una cosa cada vez y vuelve a probar.
- Explica en una frase qué fallaba y por qué.

## node-js
claves: node, javascript, npm, js, nodejs
- Node 24 instalado. Usa ES modules (`"type": "module"` en package.json, `import`).
- `fetch` y `node:fs/promises` vienen incluidos: no instales axios ni fs-extra si no hace falta.
- Instalar paquetes: `npm install paquete` dentro de la carpeta del proyecto. Ejecutar: `node archivo.mjs`.

## python
claves: python, py, pip, script python, pygame, bot en python, scraping python, automatizar con python
- Python 3.12 portátil YA está instalado para ti: en la herramienta ejecutar, `python` y `pip` funcionan directamente.
- Ejecutar: `python archivo.py`. Instalar librerías: `python -m pip install nombre` (pygame, requests, pillow, flask, discord.py...).
- Escribe el .py completo con escribir_archivo, EJECÚTALO y corrige los errores que salgan (lee el traceback: última línea = error, líneas anteriores = dónde).
- Programas interactivos (input()) no se pueden probar con ejecutar: pruébalos con datos fijos o argumentos.
- Juegos con pygame: bucle con clock.tick(60), eventos QUIT, y para pasarlo a .exe: `python -m pip install pyinstaller` y `python -m PyInstaller --onefile --noconsole juego.py` (el .exe sale en dist/).

## roblox-luau
claves: roblox, luau, lua, roblox studio, script de roblox, obby, tycoon, simulator, gamepass, datastore
- Luau de Roblox. Indica SIEMPRE dónde va cada script: Script (servidor) en ServerScriptService, LocalScript (cliente) en StarterPlayerScripts/StarterGui, ModuleScript en ReplicatedStorage.
- Servicios con `game:GetService("Players")`, etc. Nunca confíes en el cliente: valida en el servidor; comunica con RemoteEvents en ReplicatedStorage.
- Eventos: `Players.PlayerAdded:Connect(function(player) ... end)`, `part.Touched:Connect(...)` con debounce.
- Leaderstats: Folder "leaderstats" dentro del player con IntValue.
- DataStoreService con pcall y guardado en PlayerRemoving y BindToClose.
- Usa `task.wait()` y `task.spawn()` (no wait/spawn antiguos). Tipos opcionales `local x: number = 0`.
- Entrega los scripts en archivos .lua dentro de una carpeta y explica dónde pegar cada uno en Roblox Studio.

## html-css-js-app
claves: app web, herramienta, calculadora, conversor, generador, utilidad
- Apps pequeñas: un `index.html` autocontenido con interfaz cuidada (ver web-diseno-pro).
- Estado en un objeto, función `render()` que pinta desde el estado. Guarda datos en localStorage.

## api-rest-node
claves: api, servidor, backend, express, endpoint, rest
- Servidor mínimo sin dependencias con `node:http`, o Express si lo piden (`npm i express`).
- JSON con códigos de estado correctos (200, 201, 400, 404, 500). Valida la entrada.
- Puerto por variable `PORT` con valor por defecto. Explica cómo probarlo (URL en el navegador o `Invoke-RestMethod`).

## base-datos
claves: base de datos, sqlite, guardar datos, json, almacenar
- Proyectos pequeños: archivo JSON leído/escrito con fs.
- Si necesita SQL: `node:sqlite` (Node 22.5+, `import { DatabaseSync } from 'node:sqlite'`), sin instalar nada.

## git-proyectos
claves: git, github, repositorio, commit, version
- Git no está instalado en este PC: si lo necesita, `winget install Git.Git`.
- Crea `.gitignore` (node_modules, .env, builds). Nunca subir claves ni tokens.

## refactor
claves: refactoriza, limpia el codigo, mejora el codigo, optimiza, ordena
- Mantén el comportamiento igual. Extrae funciones repetidas, elimina duplicados y variables sin uso.
- Usa editar_archivo para cambios concretos; reescribe entero solo si cambia más de la mitad.

## explicar-codigo
claves: explica, que hace, entender, como funciona, aprende
- Explica de lo general a lo concreto: para qué sirve → partes → líneas clave.
- Usa analogías sencillas y un ejemplo de uso. Adapta el nivel a quien pregunta.
