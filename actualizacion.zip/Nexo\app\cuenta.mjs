// Cuenta de Nexo: propietario (tokens infinitos), licencias firmadas y tokens diarios por plan.
// - El PC del propietario tiene data/propietario.key (llave privada). NUNCA se incluye en la versión pública.
// - Las copias públicas solo llevan app/licencia-publica.pem y pueden comprobar licencias, pero no crearlas.
import fs from 'node:fs/promises';
import path from 'node:path';
import crypto from 'node:crypto';

export const LIMITES = { gratis: 30000, avanzado: 300000, ultra: 1500000 };   // tokens por día

export function crearCuenta(ROOT, APP) {
  const PRIV = path.join(ROOT, 'data', 'propietario.key');
  const PUB = path.join(APP, 'licencia-publica.pem');
  const LIC = path.join(ROOT, 'data', 'licencia.txt');
  const USO = path.join(ROOT, 'data', 'uso.json');
  let priv = null, pub = null;

  async function iniciar() {
    priv = await fs.readFile(PRIV, 'utf8').catch(() => null);
    pub = await fs.readFile(PUB, 'utf8').catch(() => null);
    if (!priv && !pub) {   // Primera vez en el PC original: se crean las llaves del propietario
      const kp = crypto.generateKeyPairSync('ed25519');
      priv = kp.privateKey.export({ type: 'pkcs8', format: 'pem' });
      pub = kp.publicKey.export({ type: 'spki', format: 'pem' });
      await fs.mkdir(path.dirname(PRIV), { recursive: true });
      await fs.writeFile(PRIV, priv, 'utf8'); await fs.writeFile(PUB, pub, 'utf8');
      console.log('[Nexo] Llaves de propietario creadas (data/propietario.key). No la compartas nunca.');
    }
  }
  const b64 = b => Buffer.from(b).toString('base64url');
  // Código de licencia: NEXO-<datos>.<firma>
  function generarLicencia(plan, nombre = '', dias = 0) {
    if (!priv) throw new Error('Solo el propietario puede crear licencias');
    const datos = { plan, nombre: String(nombre).slice(0, 40), emitida: Date.now(), ...(dias > 0 ? { caduca: Date.now() + dias * 864e5 } : {}) };
    const d = b64(JSON.stringify(datos));
    return 'NEXO-' + d + '.' + b64(crypto.sign(null, Buffer.from(d), crypto.createPrivateKey(priv)));
  }
  function verificarLicencia(code) {
    try {
      const m = String(code || '').trim().match(/^NEXO-([\w-]+)\.([\w-]+)$/); if (!m || !pub) return null;
      const sig = Buffer.from(m[2], 'base64url');
      if (sig.length !== 64 || b64(sig) !== m[2]) return null;   // solo la forma exacta del código
      if (!crypto.verify(null, Buffer.from(m[1]), crypto.createPublicKey(pub), sig)) return null;
      const d = JSON.parse(Buffer.from(m[1], 'base64url').toString('utf8'));
      if (!LIMITES[d.plan] || (d.caduca && d.caduca < Date.now())) return null;
      return d;
    } catch { return null; }
  }
  const hoy = () => new Date().toLocaleDateString('sv-SE');
  async function uso() { const u = JSON.parse(await fs.readFile(USO, 'utf8').catch(() => '{}')); return u.fecha === hoy() ? u : { fecha: hoy(), tokens: 0 }; }
  async function sumar(n) { const u = await uso(); u.tokens += Math.max(0, n | 0); await fs.writeFile(USO, JSON.stringify(u), 'utf8'); return u; }

  // Estado de la cuenta: qué plan tiene de verdad y cuántos tokens le quedan hoy
  // Versión DEMO (la pública): sin planes de pago, todo el mundo en Gratis con su límite de tokens
  const esDemo = async () => !!(await fs.stat(path.join(APP, 'demo.flag')).catch(() => null));
  async function estado(settings) {
    const propietario = !!priv;
    const demo = !propietario && await esDemo();
    const lic = demo ? null : verificarLicencia(await fs.readFile(LIC, 'utf8').catch(() => ''));
    const plan = propietario ? (settings.plan || 'ultra') : (lic?.plan || 'gratis');
    const u = await uso();
    const limite = propietario ? null : LIMITES[plan];
    return { propietario, demo, plan, licencia: lic ? { plan: lic.plan, nombre: lic.nombre, caduca: lic.caduca || null } : null,
      tokens: { usados: u.tokens, limite, quedan: limite === null ? null : Math.max(0, limite - u.tokens) } };
  }
  async function activar(code) {
    if (!priv && await esDemo()) return null;
    const d = verificarLicencia(code); if (!d) return null;
    await fs.writeFile(LIC, String(code).trim(), 'utf8'); return d;
  }
  return { iniciar, generarLicencia, verificarLicencia, estado, activar, sumar };
}
