// Contador anónimo de Nexo. Usa un contador público gratuito (Abacus): solo suma +1, no manda
// ningún dato de la persona ni sus chats. Sirve para que el dueño vea cuánta gente lo usa.
// - "instalaciones": +1 la primera vez que se abre una copia (nunca la del dueño).
// - "activos del día": +1 la primera vez que se abre cada día.
import fs from 'node:fs/promises';
import path from 'node:path';

const BASE = 'https://abacus.jasoncameron.dev';
const NS = 'nexo-neconex22-7xk2';            // espacio propio para que no choque con nadie
const hoyStr = () => new Date().toLocaleDateString('sv-SE');
const diaKey = d => 'act-' + d.replace(/-/g, '');

const hit = async k => { try { const r = await fetch(`${BASE}/hit/${NS}/${k}`, { signal: AbortSignal.timeout(8000) }); return (await r.json()).value; } catch { return null; } };
const get = async k => { try { const r = await fetch(`${BASE}/get/${NS}/${k}`, { signal: AbortSignal.timeout(8000) }); if (!r.ok) return 0; return (await r.json()).value || 0; } catch { return null; } };

export function crearStats(ROOT) {
  const LOCAL = path.join(ROOT, 'data', 'stats-local.json');
  const leer = async () => { try { return JSON.parse(await fs.readFile(LOCAL, 'utf8')); } catch { return {}; } };
  const guardar = o => fs.writeFile(LOCAL, JSON.stringify(o), 'utf8');

  // Llamar al abrir Nexo. esDueno = true en el PC original (no se cuenta a sí mismo).
  async function ping(esDueno) {
    if (esDueno) return;
    const s = await leer(); const hoy = hoyStr(); let cambia = false;
    if (!s.instalado) { await hit('instalaciones'); s.instalado = true; cambia = true; }
    if (s.ultimoDia !== hoy) { await hit(diaKey(hoy)); s.ultimoDia = hoy; cambia = true; }
    if (cambia) await guardar(s);
  }

  // Para la consola del dueño: totales + activos de los últimos 7 días.
  async function totales() {
    const dias = [];
    for (let i = 6; i >= 0; i--) {
      const d = new Date(); d.setDate(d.getDate() - i); const f = d.toLocaleDateString('sv-SE');
      dias.push({ fecha: f, activos: await get(diaKey(f)) });
    }
    return { instalaciones: await get('instalaciones'), hoy: dias[dias.length - 1].activos, dias };
  }
  return { ping, totales };
}
