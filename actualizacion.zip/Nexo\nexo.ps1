﻿. "$PSScriptRoot\_env.ps1"
$Host.UI.RawUI.WindowTitle = "Nexo (no cierres esta ventana mientras lo uses)"
Write-Host "Arrancando Nexo..." -ForegroundColor Cyan
Start-NexoOllama
$edge = @("${env:ProgramFiles(x86)}\Microsoft\Edge\Application\msedge.exe", "$env:ProgramFiles\Microsoft\Edge\Application\msedge.exe") | Where-Object { Test-Path $_ } | Select-Object -First 1
Start-Job -ArgumentList $edge, "$N\data\ventana" -ScriptBlock {
  param($edge, $perfil)
  for ($i=0; $i -lt 60; $i++) {
    Start-Sleep 1
    try {
      Invoke-WebRequest "http://127.0.0.1:3333" -UseBasicParsing -TimeoutSec 2 | Out-Null
      if ($edge) { Start-Process $edge -ArgumentList "--app=http://127.0.0.1:3333", "--user-data-dir=`"$perfil`"", "--window-size=1400,900", "--no-first-run" }
      else { Start-Process "http://127.0.0.1:3333" }
      return
    } catch {}
  }
} | Out-Null
Write-Host "Nexo en http://127.0.0.1:3333 (se abre en su propia ventana)" -ForegroundColor Green
$node = if (Test-Path "$N\tools\node\node.exe") { "$N\tools\node\node.exe" } else { "node" }
& $node "$N\app\server.mjs"
