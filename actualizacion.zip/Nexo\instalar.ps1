﻿# Instalador de Nexo. Todo se instala dentro de esta carpeta (no toca Windows).
# Uso: clic derecho -> Ejecutar con PowerShell   (o: instalar.ps1 -Pack basico|completo)
param([ValidateSet('', 'basico', 'completo')][string]$Pack = '', [switch]$SinPausa)
$ProgressPreference = 'SilentlyContinue'
[Console]::OutputEncoding = [Text.Encoding]::UTF8
$ErrorActionPreference = "Stop"
. "$PSScriptRoot\_env.ps1"
Start-Transcript "$N\instalar.log" -Append | Out-Null
function Step($t) { Write-Host "`n==== $t ====" -ForegroundColor Cyan }
New-Item -ItemType Directory -Force "$N\cache", "$N\tools" | Out-Null

Write-Host @"
  _   _
 | \ | | _____  _____
 |  \| |/ _ \ \/ / _ \     Instalador de Nexo
 | |\  |  __/>  < (_) |    IA local, privada y sin internet
 |_| \_|\___/_/\_\___/
"@ -ForegroundColor Magenta

if (-not $Pack) {
  Write-Host "`nElige qué modelos de IA descargar:" -ForegroundColor Yellow
  Write-Host "  1) Ligero   (~5 GB): Nexo Chat + Nexo Code Rápido. Para PCs con 16 GB de RAM y gráfica de 6-8 GB."
  Write-Host "  2) Completo (~50 GB): los 5 modelos (Plus, Pro, Code 30B, Ultra Code). Recomendado 32 GB de RAM."
  $r = Read-Host "Escribe 1 o 2"
  $Pack = if ($r -eq '2') { 'completo' } else { 'basico' }
}

# 1. Node.js portable (si el PC no lo tiene)
$NODE = "$N\tools\node\node.exe"
if (-not (Get-Command node -ErrorAction SilentlyContinue) -and -not (Test-Path $NODE)) {
  Step "Descargando Node.js (portable)"
  $idx = Invoke-RestMethod "https://nodejs.org/dist/index.json"
  $v = ($idx | Where-Object { $_.lts -and $_.files -contains 'win-x64-zip' } | Select-Object -First 1).version
  curl.exe -L --fail -o "$N\cache\node.zip" "https://nodejs.org/dist/$v/node-$v-win-x64.zip"
  if ($LASTEXITCODE) { throw "Fallo descargando Node.js" }
  tar.exe -xf "$N\cache\node.zip" -C "$N\tools"
  Rename-Item "$N\tools\node-$v-win-x64" "node"; Remove-Item "$N\cache\node.zip"
}

# 2. Ollama portable (el motor de IA)
if (-not (Test-Path $OLLAMA)) {
  Step "Descargando el motor de IA (Ollama portable, ~2 GB)"
  New-Item -ItemType Directory -Force "$N\ollama" | Out-Null
  curl.exe -L --fail -o "$N\cache\ollama.zip" "https://github.com/ollama/ollama/releases/latest/download/ollama-windows-amd64.zip"
  if ($LASTEXITCODE) { throw "Fallo descargando Ollama" }
  tar.exe -xf "$N\cache\ollama.zip" -C "$N\ollama"
  Remove-Item "$N\cache\ollama.zip"
}

# 3. Python portable (para que Nexo pueda programar y ejecutar Python)
if (-not (Get-ChildItem "$N\tools\python" -Recurse -Filter python.exe -ErrorAction SilentlyContinue)) {
  Step "Instalando Python portable"
  try { & "$N\tools\instalar-python.ps1" } catch { Write-Host "Python no se pudo instalar (Nexo funciona igual): $_" -ForegroundColor DarkYellow }
}

# 3b. ffmpeg (para que Nexo pueda editar vídeos e imágenes) — solo si el PC no lo tiene ya
if (-not (Get-Command ffmpeg -ErrorAction SilentlyContinue) -and -not (Test-Path "$N\tools\ffmpeg\bin\ffmpeg.exe")) {
  Step "Instalando ffmpeg (vídeo e imágenes, ~90 MB)"
  try {
    curl.exe -L --fail -o "$N\cache\ffmpeg.zip" "https://github.com/GyanD/codexffmpeg/releases/latest/download/ffmpeg-release-essentials.zip"
    if ($LASTEXITCODE) { throw "descarga" }
    tar.exe -xf "$N\cache\ffmpeg.zip" -C "$N\cache"
    $ff = Get-ChildItem "$N\cache" -Directory -Filter "ffmpeg-*" | Select-Object -First 1
    New-Item -ItemType Directory -Force "$N\tools\ffmpeg" | Out-Null
    Move-Item "$($ff.FullName)\bin" "$N\tools\ffmpeg\bin" -Force
    Remove-Item "$N\cache\ffmpeg.zip", $ff.FullName -Recurse -Force
  } catch { Write-Host "ffmpeg no se pudo instalar (el vídeo no funcionará, el resto sí): $_" -ForegroundColor DarkYellow }
}

# 4. Modelos
Step "Arrancando el motor"
Start-NexoOllama
# Qué modelos lleva cada pack (el modelo de IA de cada uno sale del "FROM" de su Modelfile)
$lista = @("nexo-chat", "nexo-code-rapido")
if ($Pack -eq 'completo') { $lista += @("nexo-plus", "nexo-pro", "nexo-code") }
foreach ($k in $lista) {
  $mf = "$N\modelfiles\$k.Modelfile"
  if (-not (Test-Path $mf)) { continue }
  $base = ((Select-String -Path $mf -Pattern '^\s*FROM\s+(.+)$').Matches[0].Groups[1].Value).Trim()
  Step "Descargando $k ($base)"
  & $OLLAMA pull $base
  if ($LASTEXITCODE) { Write-Host "ERROR descargando $base" -ForegroundColor Red; continue }
  & $OLLAMA create $k -f $mf
}

Step "Listo"
& $OLLAMA list
Write-Host "`nNEXO INSTALADO. Ábrelo con 'Abrir Nexo.bat'." -ForegroundColor Green
Write-Host "Empiezas en el plan Gratis (30.000 tokens al día). Si tienes un código de licencia, actívalo en Ajustes -> Planes." -ForegroundColor Gray
Stop-Transcript | Out-Null
if (-not $SinPausa) { Read-Host "Pulsa Enter para cerrar" }
