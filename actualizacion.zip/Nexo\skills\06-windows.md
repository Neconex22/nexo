# Windows, archivos y .exe

## crear-exe
claves: exe, ejecutable, .exe, programa de windows, doble clic, aplicacion de escritorio
SÍ puedes crear .exe. Nunca digas que no puedes. Dos formas:
1. Juego o app web (HTML): crea la carpeta con index.html y usa la herramienta `crear_exe` con la carpeta. Genera un .exe que abre el juego en su propia ventana sin barra del navegador.
2. Programa nativo en C#: escribe el `.cs` y usa la herramienta `compilar_csharp` (consola o ventana). Ver crear-exe-csharp.
Después, abre la carpeta para que el usuario vea el .exe.

## crear-exe-csharp
claves: c#, csharp, winforms, programa nativo, consola
- Compilador de Windows (.NET Framework 4.8, C# 5): NO uses `$"..."` interpolación, ni `?.`, ni `=>` en propiedades, ni `var` en campos, ni tuplas. Usa `string.Format` y sintaxis clásica.
- Ventana: `using System.Windows.Forms; using System.Drawing;` clase que hereda de `Form`, `[STAThread] static void Main(){ Application.EnableVisualStyles(); Application.Run(new MiForm()); }`.
- Consola: `static void Main(){ ... Console.ReadKey(); }` y modo "consola" en compilar_csharp.
- Si da errores de compilación, léelos (línea y columna), corrige con editar_archivo y vuelve a compilar.

## organizar-archivos
claves: organiza, ordenar, archivos, carpeta desordenada, descargas, limpiar carpeta
- Primero LISTA y enseña el plan (qué se moverá a dónde). Agrupa por tipo: Imágenes, Vídeos, Documentos, Música, Comprimidos, Programas.
- Mueve con la herramienta mover (no borres). Al final resume cuántos archivos movió.
- Varios archivos por extensión en PowerShell: `Get-ChildItem -File *.jpg | Move-Item -Destination "Imagenes"`.

## renombrar-masivo
claves: renombrar, cambiar nombre, numerar, renombra
- PowerShell: `$i=1; Get-ChildItem *.mp4 | Sort-Object Name | ForEach-Object { Rename-Item $_ -NewName ("clip_{0:D3}.mp4" -f $i); $i++ }`.
- Enseña antes 2-3 ejemplos del resultado.

## buscar-archivos
claves: buscar archivo, encontrar, donde esta, localizar
- `Get-ChildItem -Path "C:\Users\..." -Recurse -Filter "*nombre*" -ErrorAction SilentlyContinue | Select-Object -First 30 FullName`.
- Archivos grandes: `Get-ChildItem -Recurse -File | Sort-Object Length -Descending | Select-Object -First 20 FullName, @{n='MB';e={[int]($_.Length/1MB)}}`.

## comprimir-zip
claves: zip, comprimir, descomprimir, rar, extraer
- `Compress-Archive -Path "carpeta\*" -DestinationPath "archivo.zip" -Force`.
- `Expand-Archive "archivo.zip" -DestinationPath "destino" -Force`. Para .rar/.7z: `tar -xf archivo.rar` a veces funciona; si no, 7-Zip.

## info-pc
claves: mi pc, especificaciones, ram, grafica, cpu, espacio, disco, temperatura
- RAM y CPU: `Get-CimInstance Win32_ComputerSystem; Get-CimInstance Win32_Processor | Select Name, NumberOfCores`.
- GPU: `nvidia-smi`. Discos: `Get-PSDrive -PSProvider FileSystem`.
- Procesos que más gastan: `Get-Process | Sort-Object CPU -Descending | Select -First 10 Name, CPU, @{n='MB';e={[int]($_.WS/1MB)}}`.

## instalar-programas
claves: instalar, descargar programa, winget, app
- Usa `winget search nombre` y `winget install --id Id.Exacto -e --accept-source-agreements --accept-package-agreements`.
- Pide permiso antes de instalar y di qué se va a instalar. Solo fuentes oficiales.

## automatizar-tareas
claves: automatizar, script, tarea repetitiva, bat, cada dia, programar tarea
- Crea un `.ps1` con la tarea y un `.bat` lanzador: `powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0tarea.ps1"`.
- Tareas programadas con `schtasks` solo si el usuario lo pide expresamente.

## seguridad-pc
claves: virus, seguro, peligroso, borrar todo, formatear, registro
- Nunca ejecutes comandos destructivos (Remove-Item -Recurse en carpetas del sistema, format, reg delete, desactivar antivirus) sin una petición clara y explícita.
- Para borrar usa la herramienta borrar (va a la Papelera). Desconfía de scripts descargados.
