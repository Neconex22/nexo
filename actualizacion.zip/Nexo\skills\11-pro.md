# Diseño 3D, publicar y controlar el PC

## blender-3d
claves: blender, 3d, modelo 3d, render, diseño 3d, logo 3d, escena 3d, modela, modelar
Para diseño 3D usa la herramienta `blender_3d` con un script de Python (bpy) COMPLETO que:
1. Limpia la escena: `import bpy; bpy.ops.object.select_all(action='SELECT'); bpy.ops.object.delete()`.
2. Crea la geometría (bpy.ops.mesh.primitive_* o bmesh), materiales (nodos Principled BSDF), modificadores (bevel, subsurf).
3. Pone cámara y luz, y `bpy.context.scene.camera`.
4. Ajusta el render: `scene.render.engine = 'BLENDER_EEVEE_NEXT'` (rápido) o 'CYCLES'; `scene.render.resolution_x/y`; `scene.render.film_transparent = True` si quieren fondo transparente.
5. Renderiza a la ruta de salida: `scene.render.filepath = r'RUTA'; bpy.ops.render.render(write_still=True)`.
6. Opcional: guarda el .blend con `bpy.ops.wm.save_as_mainfile(filepath=r'RUTA.blend')`.
- Colores: material.diffuse_color y el nodo Principled BSDF 'Base Color' (RGBA 0-1).
- Si Blender no está instalado, la herramienta lo dice: instálalo con `ejecutar` → `winget install -e --id BlenderFoundation.Blender --accept-source-agreements --accept-package-agreements` y reintenta.
- Al acabar, abre el PNG con `abrir`.

## publicar-web
claves: publica, publicar, sube la web, comparte la web, enlace de mi web, hostear, poner en internet, link de la web
- Para compartir una web AL MOMENTO: `publicar_web` con la carpeta (debe tener index.html) → da un enlace https temporal (trycloudflare) que funciona mientras Nexo esté abierto. Perfecto para enseñársela a un amigo ya.
- Para algo PERMANENTE hace falta GitHub Pages o Netlify, que necesitan una cuenta: explica los pasos, no inventes que lo has publicado permanentemente.
- Prueba la web con `probar_web` antes de publicarla.

## controlar-pc
claves: abre, abrir, instala, instalar, programa, pon, busca en el pc, ejecuta, lanza, descarga programa
Nexo controla el PC con sus herramientas:
- Abrir programas, carpetas, webs o archivos: herramienta `abrir` (o `ejecutar` con "start ...").
- Instalar programas: `ejecutar` → `winget install -e --id <Id> --accept-source-agreements --accept-package-agreements` (pide el Id con `winget search nombre`). Avisa de qué instalas.
- Buscar en internet: `buscar_web`. Buscar archivos en el PC: `ejecutar` con Get-ChildItem -Recurse.
- Cerrar/abrir apps, ver procesos, limpiar: PowerShell con `ejecutar`.
- NUNCA comandos destructivos del sistema sin que lo pidan claro. Pide permiso lo delicado (ya lo hace la interfaz).

## tienda-dropshipping
claves: tienda, dropshipping, shopify, productos, vender, ecommerce, catalogo, tienda online
- Monta la estructura: página de inicio, catálogo, fichas de producto (foto, nombre, precio en €, descripción persuasiva, envío y devoluciones), carrito en localStorage. Usa la skill web-tienda.
- Fichas de producto con buena copy (beneficio, no características) y precios con formato español.
- Para cobrar de verdad hace falta una pasarela (Stripe/PayPal) y una cuenta de un adulto: dilo claramente, no simules ventas reales.
- Puedes generar el catálogo como JSON y una web que lo lea.

## roblox-pro
claves: roblox, juego de roblox, luau, roblox studio, obby, tycoon, simulator, gamepass
- Entrega los scripts en una carpeta ordenada, con un LÉEME que diga EXACTAMENTE dónde pega cada uno en Roblox Studio (ServerScriptService, StarterPlayerScripts, ReplicatedStorage...).
- Da el juego por partes: primero lo básico que funcione, luego añades. Usa la skill roblox-luau para el código.
- Si piden un mapa/obby, da también instrucciones de cómo colocar las partes, o un script que las genere al ejecutarse en Studio.

## diseño-grafico-pro
claves: diseño, logo, cartel, poster, banner, miniatura, portada, grafico, imagen diseño
- Diseño 2D de calidad: hazlo en HTML/SVG a tamaño exacto y expórtalo a PNG con Edge headless (`msedge --headless=new --screenshot=salida.png --window-size=ANCHO,ALTO --default-background-color=00000000 "file:///.../x.html"`).
- Sigue las skills web-diseno-pro y evitar-cliches-diseno (nada de degradado morado-azul por defecto).
- Para 3D, usa blender-3d. Para editar fotos, ffmpeg (escalar, recortar, convertir).
