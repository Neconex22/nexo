# Escritura y estudio

## email-mensaje
claves: email, correo, mensaje, whatsapp, escribir a, carta
- Asunto claro. Saludo, el motivo en la primera frase, detalles, petición concreta y despedida.
- Ajusta el tono (formal/cercano) al destinatario. Breve.

## resumir
claves: resume, resumen, resumir, sintetiza, puntos clave
- Primero una frase con la idea principal, luego 3-6 puntos clave. Mantén cifras y nombres.
- Si es un archivo, léelo con leer_archivo antes.

## trabajo-clase
claves: trabajo, deberes, clase, instituto, colegio, examen, redaccion, exposicion
- Ayuda a entender y a estructurar (introducción, desarrollo, conclusión) en vez de dar solo la respuesta.
- Ejemplos y explicaciones sencillas. Puedes crear el documento en .md o .html para imprimir.

## matematicas
claves: matematicas, ecuacion, problema, calcula, porcentaje, fisica
- Resuelve paso a paso, mostrando cada operación. Comprueba el resultado al final.
- Para cálculos largos, usa ejecutar con PowerShell o Node para no equivocarte.

## traducir
claves: traduce, traduccion, ingles, en ingles, idioma
- Traduce el sentido, no palabra por palabra. Mantén el tono y los nombres propios.
- Si hay expresiones sin equivalente, adapta y explica.

## historias-creativas
claves: historia, cuento, relato, rol, personaje, lore
- Personajes con deseo y conflicto. Muestra con acciones y diálogo, no lo cuentes todo.
- Final con giro o emoción. Pregunta el tono (épico, humor, terror) si no está claro.

## documento-html
claves: documento, informe, pdf, imprimir, word, guia
- Crea un `.html` con estilo de documento (márgenes, tipografía serif para texto, títulos claros) y `@media print`.
- Para PDF: ábrelo en el navegador y Ctrl+P → Guardar como PDF, o Edge sin ventana: `msedge --headless --print-to-pdf="salida.pdf" "archivo.html"`.

## tablas-datos
claves: tabla, excel, csv, lista, datos, hoja de calculo
- Para Excel genera un `.csv` con separador `;` y codificación UTF-8 con BOM (Excel en español lo abre bien).
- Tablas en Markdown para mostrar en el chat.

## presentacion
claves: presentacion, diapositivas, powerpoint, exposicion, slides
- HTML de diapositivas a pantalla completa navegables con flechas: una idea por diapositiva, poco texto, títulos grandes.
- Estructura: portada, índice, 3-6 diapositivas de contenido, conclusión.

## aprender-algo
claves: enseñame, aprender, curso, como se hace, tutorial
- Plan de aprendizaje en pasos pequeños con un ejercicio práctico por paso.
- Comprueba lo aprendido con una pregunta al final.
