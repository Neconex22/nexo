// Nexo - servidor local (sin dependencias). Habla con Ollama en 127.0.0.1:11434.
import http from 'node:http';
import fs from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { randomUUID } from 'node:crypto';
import os from 'node:os';
import { MODELS, EFFORTS, PLANS, agentPrompt } from './config.mjs';
import { TOOL_DEFS, runTool, needsApproval, toolIcon, readMemoria, writeMemoria } from './tools.mjs';
import { state as juego, pause, resume, track, startWatcher, CPU_THREADS } from './juego.mjs';
import { loadSkills, pickSkills, norm } from './skills.mjs';
import { crearCuenta, LIMITES } from './cuenta.mjs';
import { crearActualizador, reiniciarServidor } from './actualizar.mjs';
import { crearStats } from './stats.mjs';
import { spawn } from 'node:child_process';
import { createReadStream, createWriteStream } from 'node:fs';

const APP = path.dirname(fileURLToPath(import.meta.url));
const ROOT = path.resolve(APP, '..');
const DATA = path.join(ROOT, 'data');
const CHATS = path.join(DATA, 'chats');
const SETTINGS = path.join(DATA, 'ajustes.json');
const SKILLS = path.join(ROOT, 'skills');
const OLLAMA = process.env.OLLAMA_URL || 'http://127.0.0.1:11434';
const PORT = Number(process.env.NEXO_PORT || 3333);

await fs.mkdir(CHATS, { recursive: true });
const cuenta = crearCuenta(ROOT, APP);
await cuenta.iniciar();
const stats = crearStats(ROOT);

const STATIC = {
  '/': ['public/index.html', 'text/html'],
  '/app.css': ['public/app.css', 'text/css'],
  '/app.js': ['public/app.js', 'text/javascript'],
  '/logo.svg': ['public/logo.svg', 'image/svg+xml'],
  '/vendor/marked.js': ['node_modules/marked/lib/marked.umd.js', 'text/javascript'],
  '/vendor/purify.js': ['node_modules/dompurify/dist/purify.min.js', 'text/javascript'],
  '/vendor/hljs.js': ['node_modules/@highlightjs/cdn-assets/highlight.min.js', 'text/javascript'],
  '/vendor/hljs.css': ['node_modules/@highlightjs/cdn-assets/styles/github-dark.min.css', 'text/css'],
};

async function readJSON(file, def) { try { return JSON.parse(await fs.readFile(file, 'utf8')); } catch { return def; } }
async function writeJSON(file, obj) { await fs.writeFile(file, JSON.stringify(obj, null, 1), 'utf8'); }
const getSettings = async () => ({ plan: 'ultra', model: 'nexo-auto', effort: 'medio', permisos: 'ask', agent: true,
  workspaceDefault: path.join(ROOT, 'trabajos'), ...(await readJSON(SETTINGS, {})) });

function send(res, code, body, type = 'application/json') {
  res.writeHead(code, { 'Content-Type': type + '; charset=utf-8', 'Cache-Control': 'no-store' });
  res.end(typeof body === 'string' || Buffer.isBuffer(body) ? body : JSON.stringify(body));
}
async function body(req) {
  const chunks = []; for await (const c of req) chunks.push(c);
  try { return JSON.parse(Buffer.concat(chunks).toString('utf8') || '{}'); } catch { return {}; }
}
const safeId = id => /^[a-f0-9-]{36}$/.test(id) ? id : null;

async function allChats(dir = CHATS) {
  const files = (await fs.readdir(dir).catch(() => [])).filter(f => f.endsWith('.json'));
  const list = [];
  for (const f of files) { const c = await readJSON(path.join(dir, f), null); if (c) list.push(c); }
  return list.sort((a, b) => b.updated - a.updated);
}
const KIND = e => /\.(mp4|mov|mkv|webm|avi)$/i.test(e) ? 'video' : /\.(png|jpe?g|gif|webp|svg|ico)$/i.test(e) ? 'imagen' : /\.(mp3|wav|ogg|m4a)$/i.test(e) ? 'audio'
  : /\.exe$/i.test(e) ? 'exe' : /\.html?$/i.test(e) ? 'web' : /\.(js|mjs|ts|cs|py|css|json|ps1|bat|lua)$/i.test(e) ? 'codigo' : 'archivo';
async function walk(dir, root, out, depth) {
  if (depth > 4 || out.length > 1000) return;
  for (const it of await fs.readdir(dir, { withFileTypes: true }).catch(() => [])) {
    if (it.name === 'node_modules' || it.name.startsWith('.')) continue;
    const full = path.join(dir, it.name);
    if (it.isDirectory()) await walk(full, root, out, depth + 1);
    else { const st = await fs.stat(full).catch(() => null); if (st) out.push({ name: it.name, rel: path.relative(root, full), size: st.size, mtime: st.mtimeMs, kind: KIND(it.name) }); }
  }
}

async function installedModels() {
  try {
    const r = await fetch(OLLAMA + '/api/tags', { signal: AbortSignal.timeout(3000) });
    const j = await r.json();
    return j.models.map(m => m.name.replace(/:latest$/, ''));
  } catch { return null; }
}

// Busca llamadas a herramientas escritas como JSON en el texto: {"name": "...", "arguments": {...}}
const TOOL_NAMES = new Set(TOOL_DEFS.map(d => d.function.name));
function textToolCalls(text) {
  const calls = [];
  const src = String(text || '').replace(/<\/?tool_call>/g, '\n');
  for (let i = src.indexOf('{'); i >= 0 && i < src.length; i = src.indexOf('{', i + 1)) {
    let depth = 0, inStr = false, esc = false, j = i;
    for (; j < src.length; j++) {
      const ch = src[j];
      if (inStr) { if (esc) esc = false; else if (ch === '\\') esc = true; else if (ch === '"') inStr = false; continue; }
      if (ch === '"') inStr = true; else if (ch === '{') depth++; else if (ch === '}' && --depth === 0) break;
    }
    if (depth !== 0) break;
    try {
      const o = JSON.parse(src.slice(i, j + 1));
      const name = o.name || o.function?.name; const args = o.arguments ?? o.parameters ?? o.function?.arguments ?? {};
      if (TOOL_NAMES.has(name)) { calls.push({ function: { name, arguments: typeof args === 'string' ? JSON.parse(args) : args } }); i = j; }
    } catch {}
  }
  return calls;
}

// Mata procesos del motor que se hayan quedado colgados ocupando la gráfica
function killRunners() {
  return new Promise(r => { const p = spawn('taskkill', ['/F', '/IM', 'llama-server.exe'], { windowsHide: true }); p.on('close', r); p.on('error', r); });
}
const loadedModels = async () => { try { return ((await (await fetch(OLLAMA + '/api/ps', { signal: AbortSignal.timeout(3000) })).json()).models || []).map(x => x.name.replace(/:latest$/, '')); } catch { return []; } };
// Antes de cargar un modelo distinto, descarga el anterior y espera a que la gráfica quede libre
let switching = Promise.resolve();
function prepareModel(id, status) {
  switching = switching.then(async () => {
    const loaded = await loadedModels();
    const others = loaded.filter(n => n !== id);
    if (!others.length) return;
    status?.('_(Cambiando de modelo…)_\n\n');
    await Promise.all(others.map(n => fetch(OLLAMA + '/api/generate', { method: 'POST', body: JSON.stringify({ model: n, keep_alive: 0 }) }).catch(() => {})));
    for (let i = 0; i < 20; i++) { await new Promise(r => setTimeout(r, 500)); if (!(await loadedModels()).some(n => n !== id)) return; }
    await killRunners(); await new Promise(r => setTimeout(r, 1500));   // se quedó colgado: forzar
  }).catch(() => {});
  return switching;
}

// Permisos pendientes: id -> resolve(decision)
const approvals = new Map();
const calentando = new Set();   // modelos que ya se están precalentando
const MAX_STEPS = 30;

async function chat(req, res) {
  const { model, effort, messages, agent } = await body(req);
  const s = await getSettings();
  const cta = await cuenta.estado(s);
  const plan = PLANS.find(p => p.id === cta.plan) || PLANS[0];
  if (cta.tokens.limite !== null && cta.tokens.quedan <= 0)
    return send(res, 429, { error: `Has gastado los ${cta.tokens.limite.toLocaleString('es-ES')} tokens de hoy. Mañana se recargan.` });
  let m = MODELS.find(x => x.id === model);
  const e = EFFORTS.find(x => x.id === effort);
  if (!m || !e) return send(res, 400, { error: 'Modelo o esfuerzo no válido' });
  let autoChosen = null;
  if (m.id === 'nexo-auto') {
    const inst = (await installedModels()) || [];
    const users0 = (messages || []).filter(x => x.role === 'user'); const last0 = users0.slice(-1)[0] || {};
    const cats = pickSkills(await loadSkills(SKILLS), String(last0.content || ''), [], 3).map(k => k.cat);
    const ok = id => plan.models.includes(id) && inst.includes(id);
    // Decide por la skill principal (la que mejor encaja), no por cualquiera
    const code = /Programaci|Juegos|Web|Windows|Bots/i.test(cats[0] || '');
    let pick;
    if (last0.images?.length && ok('nexo-plus')) pick = 'nexo-plus';
    else if (code) pick = ['nexo-code', 'nexo-code-rapido', 'nexo-chat'].find(ok);
    else if (['alto', 'maximo'].includes(e.id) && ok('nexo-pro')) pick = 'nexo-pro';
    else if (cats.some(c => /humano|Escritura|Contenido/i.test(c)) && !cats.some(c => /V[ií]deo/i.test(c)) && ok('nexo-plus') && !/crea|guarda|archivo|carpeta/i.test(last0.content || '')) pick = 'nexo-plus';
    pick = pick || ['nexo-chat', 'nexo-code-rapido'].find(ok) || 'nexo-chat';
    m = MODELS.find(x => x.id === pick); autoChosen = m.name;
  }
  if (!plan.models.includes(m.id)) return send(res, 403, { error: `${m.name} no está en tu plan ${plan.name}` });
  if (!plan.efforts.includes(e.id)) return send(res, 403, { error: `El esfuerzo ${e.name} no está en tu plan ${plan.name}` });

  if (juego.paused) return send(res, 423, { error: juego.game ? `Nexo está en pausa porque estás jugando a ${juego.game}. Ciérralo o pulsa Reanudar.` : 'Nexo está en Modo juego (pausa). Pulsa Reanudar para usarlo.' });
  const useTools = !!agent && m.tools;
  const ws = s.workspace || path.join(ROOT, 'trabajos');
  await fs.mkdir(ws, { recursive: true }).catch(() => {});
  let sys = m.persona;
  if (e.prompt) sys += '\n' + e.prompt;
  if (useTools) sys += '\n' + agentPrompt(ws, os.homedir());
  // Skills: las mas relevantes para lo que pide el usuario
  const users = (messages || []).filter(x => x.role === 'user');
  const lastUser = users.slice(-1)[0]?.content || '';
  const ctxText = lastUser + ' ' + (lastUser.length < 60 ? (users.slice(-2)[0]?.content || '') : '');
  const picked = pickSkills(await loadSkills(SKILLS), ctxText, s.skillsOff || [], e.id === 'bajo' ? 2 : 3);
  if (picked.length) sys += '\n\nSKILLS (conocimientos expertos que debes aplicar en esta tarea):\n' + picked.map(k => `### ${k.name}\n${k.body}`).join('\n\n');
  if (s.system) sys += '\n\nInstrucciones personales del usuario:\n' + s.system;
  if (s.userName) sys += `\nEl usuario se llama ${s.userName}.`;
  const mem = await readMemoria();
  if (mem.length) sys += '\n\nLO QUE RECUERDAS DEL USUARIO (de otros chats; úsalo cuando venga a cuento, sin repetirlo sin motivo):\n' + mem.map(x => '- ' + x).join('\n');
  if (useTools) sys += '\nSi el usuario te cuenta algo importante y duradero de sí mismo o te pide que recuerdes algo, guárdalo con la herramienta recordar.';
  const msgs = [{ role: 'system', content: sys }];
  for (const x of messages || []) {
    const o = { role: x.role === 'assistant' ? 'assistant' : 'user', content: String(x.content || '') };
    if (m.vision && Array.isArray(x.images) && x.images.length) o.images = x.images.map(i => String(i).replace(/^data:[^,]+,/, ''));
    msgs.push(o);
  }

  const ac = new AbortController();
  const untrack = track(ac);
  res.on('close', () => { untrack(); if (!res.writableFinished) ac.abort(); });
  const out = o => { if (!res.writableEnded) res.write(JSON.stringify(o) + '\n'); };
  res.writeHead(200, { 'Content-Type': 'application/x-ndjson; charset=utf-8', 'Cache-Control': 'no-store' });

  if (autoChosen) out({ t: 'auto', model: m.id, name: autoChosen });
  if (picked.length) out({ t: 'skills', names: picked.map(k => k.name) });

  // ---- Nexo Max: cerebro de verdad (usa una IA potente de internet con la clave del usuario) ----
  if (m.cloud) {
    const c = s.cloud || {};
    if (!c.key || !c.url || !c.model) {
      out({ t: 'text', d: 'Nexo Max usa una IA potente de internet (como Claude o GPT) para ser mucho más listo, pero necesitas una clave.\n\nActívalo en **⚙ Ajustes → Nexo Max**: pega la dirección, tu clave y el modelo. Lo más fácil es una cuenta de OpenRouter (openrouter.ai), que con una sola clave te da acceso a Claude, GPT y Gemini. Necesitas poner unos pocos € de saldo (y, si eres menor, que lo haga un adulto).' });
      out({ t: 'done' }); return res.end();
    }
    try {
      const up = await fetch(c.url.replace(/\/+$/, '') + '/chat/completions', {
        method: 'POST', signal: ac.signal,
        headers: { 'Content-Type': 'application/json', 'Authorization': 'Bearer ' + c.key, 'HTTP-Referer': 'https://nexo.local', 'X-Title': 'Nexo' },
        body: JSON.stringify({ model: c.model, stream: true, messages: msgs.map(x => ({ role: x.role, content: x.content })) })
      });
      if (!up.ok) { let t = await up.text().catch(() => ''); out({ t: 'error', d: `La IA de internet rechazó la petición (${up.status}). Revisa la clave, el saldo y el nombre del modelo en Ajustes → Nexo Max.\n${t.slice(0, 300)}` }); out({ t: 'done' }); return res.end(); }
      const dec = new TextDecoder(); let buf = '';
      for await (const chunk of up.body) {
        buf += dec.decode(chunk, { stream: true }); let i;
        while ((i = buf.indexOf('\n')) >= 0) {
          const line = buf.slice(0, i).trim(); buf = buf.slice(i + 1);
          if (!line.startsWith('data:')) continue;
          const data = line.slice(5).trim(); if (data === '[DONE]') continue;
          let j; try { j = JSON.parse(data); } catch { continue; }
          const d = j.choices?.[0]?.delta?.content; if (d) out({ t: 'text', d });
          if (j.usage?.total_tokens) gastados = j.usage.total_tokens;
        }
      }
    } catch (err) { if (!ac.signal.aborted) out({ t: 'error', d: 'No se pudo conectar con la IA de internet: ' + (err.message || err) }); }
    if (!gastados) gastados = Math.ceil((msgs.map(x => x.content).join(' ').length) / 3);
    const u2 = await cuenta.sumar(gastados).catch(() => null);
    out({ t: 'done', tokens: gastados, hoy: u2?.tokens }); return res.end();
  }

  let allowAll = s.permisos === 'auto' ? 'auto' : 'ask';
  let retried = false, parseFails = 0, gastados = 0, revisiones = 0, usoHerramientas = false;
  let statusShown = false;
  const ollamaModel = m.base || m.id;   // Ultra Code usa el modelo de Nexo Code por debajo
  await prepareModel(ollamaModel, t => { if (!statusShown) { statusShown = true; } });
  // Recortar historial para que quepa en la memoria del modelo (si no, Ollama borra el principio: ¡las instrucciones!)
  const ctxTok = e.ctx || (useTools ? ((m.base || m.id) === 'nexo-code' ? 32768 : 16384) : (m.tipo === 'code' ? 16384 : 8192));
  const tok = x => Math.ceil(String(x.content || '').length / 3.2) + (x.images?.length || 0) * 300;
  let budget = Math.floor(ctxTok * 0.7) - tok(msgs[0]);
  const keep = [];
  for (let i = msgs.length - 1; i >= 1; i--) { const t = tok(msgs[i]); if (keep.length && budget - t < 0) break; budget -= t; keep.unshift(msgs[i]); }
  if (keep.length < msgs.length - 1) { msgs.splice(1, msgs.length - 1, { role: 'user', content: '(Mensajes antiguos de esta conversación omitidos por longitud.)' }, { role: 'assistant', content: 'Entendido.' }, ...keep); }
  try {
    for (let step = 0; step < (m.ultra ? 50 : MAX_STEPS); step++) {
      const payload = { model: ollamaModel, messages: msgs, stream: true, keep_alive: '5m', options: { num_thread: CPU_THREADS } };
      if (m.think === 'bool') payload.think = e.think;
      if (m.think === 'level') payload.think = e.level;
      if (e.ctx) payload.options.num_ctx = e.ctx;
      else if (useTools) payload.options.num_ctx = ollamaModel === 'nexo-code' ? 32768 : 16384;   // Nexo Code: más memoria para proyectos grandes
      if (useTools) payload.tools = TOOL_DEFS;

      let up;
      try { up = await fetch(OLLAMA + '/api/chat', { method: 'POST', body: JSON.stringify(payload), signal: ac.signal }); }
      catch (err) { if (ac.signal.aborted) break; out({ t: 'error', d: 'Ollama no responde. ¿Está abierto Nexo?' }); break; }
      if (!up.ok) {
        let t = await up.text(); try { t = JSON.parse(t).error; } catch {}
        // Motor colgado (CUDA / runner muerto): matar procesos huérfanos y reintentar una vez
        if (!retried && /CUDA|llama-server|runner|terminated|0xc0000409|out of memory/i.test(String(t))) {
          retried = true;
          await killRunners(); await new Promise(r => setTimeout(r, 2500)); step--; continue;
        }
        out({ t: 'error', d: 'Error del modelo: ' + t }); break;
      }

      let content = '', thinking = '', calls = [], parseErr = false;
      const dec = new TextDecoder(); let buf = '';
      for await (const chunk of up.body) {
        buf += dec.decode(chunk, { stream: true }); let i;
        while ((i = buf.indexOf('\n')) >= 0) {
          const line = buf.slice(0, i).trim(); buf = buf.slice(i + 1); if (!line) continue;
          let j; try { j = JSON.parse(line); } catch { continue; }
          if (j.error) {
            if (/error parsing tool call/i.test(j.error) && parseFails < 2) { parseErr = true; continue; }
            out({ t: 'error', d: j.error }); continue;
          }
          if (j.message?.thinking) { thinking += j.message.thinking; out({ t: 'think', d: j.message.thinking }); }
          if (j.message?.content) { content += j.message.content; out({ t: 'text', d: j.message.content }); }
          if (j.message?.tool_calls?.length) calls.push(...j.message.tool_calls);
          if (j.done) { out({ t: 'speed', speed: j.eval_duration ? +(j.eval_count / (j.eval_duration / 1e9)).toFixed(1) : null }); gastados += (j.eval_count || 0) + (j.prompt_eval_count || 0); }
        }
      }
      // Algunos modelos escriben la llamada como texto JSON: la detectamos y la ejecutamos
      if (!calls.length && useTools) {
        const found = textToolCalls(content);
        if (found.length) { calls = found; out({ t: 'untext' }); content = ''; }
      }
      if (!calls.length && parseErr) {
        parseFails++;
        msgs.push({ role: 'assistant', content: content || '(llamada a herramienta)' });
        msgs.push({ role: 'user', content: '(Aviso del sistema) Tu última llamada a una herramienta tenía JSON inválido, seguramente por las barras invertidas \\ de una ruta. Repítela usando rutas RELATIVAS con barras normales "/" (ej: "web-neconex3/index.html") y continúa la tarea.' });
        continue;
      }
      if (!calls.length) {
        // Ultra Code: antes de terminar, se revisa y prueba a sí mismo (hasta 2 rondas)
        if (m.ultra && usoHerramientas && revisiones < 2) {
          revisiones++;
          msgs.push({ role: 'assistant', content: content || '(hecho)' });
          msgs.push({ role: 'user', content: revisiones === 1
            ? '(Revisión Ultra 1/2) Antes de dar el trabajo por terminado, actúa como un revisor de código exigente: vuelve a LEER los archivos que has creado o cambiado, PRUÉBALOS (probar_web para webs/juegos, ejecutar para scripts y programas) y busca errores, casos límite, cosas sin terminar, textos de relleno y mejoras de calidad o diseño. Corrige todo lo que encuentres con las herramientas. Si todo está perfecto, dilo.'
            : '(Revisión Ultra 2/2) Última comprobación: ejecuta o prueba una vez más el resultado final para confirmar que funciona sin errores. Después responde con un resumen final claro: qué has hecho, dónde está y cómo usarlo.' });
          out({ t: 'text', d: `\n\n_🔁 Revisión Ultra ${revisiones}/2: comprobando y mejorando el trabajo…_\n\n` });
          continue;
        }
        break;
      }
      usoHerramientas = true;

      msgs.push({ role: 'assistant', content, ...(thinking ? { thinking } : {}), tool_calls: calls });
      for (const c of calls) {
        const name = c.function?.name; let args = c.function?.arguments || {};
        if (typeof args === 'string') { try { args = JSON.parse(args); } catch { args = {}; } }
        const id = randomUUID();
        const show = { ...args }; if (typeof show.contenido === 'string' && show.contenido.length > 4000) show.contenido = show.contenido.slice(0, 4000) + '\n…';
        out({ t: 'tool', id, name, icon: toolIcon(name), args: show });
        let result;
        if (!TOOL_DEFS.some(d => d.function.name === name)) result = 'Error: esa herramienta no existe.';
        else if (allowAll === 'ask' && needsApproval(name, args, ws, 'ask')) {
          out({ t: 'ask', id });
          const dec2 = await new Promise(resolve => { approvals.set(id, resolve); ac.signal.addEventListener('abort', () => resolve('no')); });
          approvals.delete(id);
          if (dec2 === 'siempre') allowAll = 'auto';
          if (dec2 === 'no') result = `El usuario ha DENEGADO esta acción concreta (no la repitas igual). Si la ruta estaba fuera del espacio de trabajo, usa una ruta RELATIVA (dentro de ${ws}) y CONTINÚA con la tarea. Si era un comando, busca otra forma de hacerlo o pregunta qué prefiere.`;
        }
        if (ac.signal.aborted) break;
        if (result === undefined) {
          out({ t: 'running', id });
          try { result = await runTool(name, args, ws, ac.signal); } catch (err) { result = 'Error: ' + (err.message || err); }
        }
        out({ t: 'result', id, ok: !/^Error|DENEGADO|^\(código de salida [1-9-]/.test(result), d: result.length > 6000 ? result.slice(0, 6000) + '\n…' : result });
        msgs.push({ role: 'tool', content: result.length > 8000 ? result.slice(0, 8000) + '\n…(recortado)' : result, tool_name: name });
      }
      if (ac.signal.aborted) break;
      out({ t: 'text', d: '\n\n' });
    }
  } catch (err) { if (!ac.signal.aborted) out({ t: 'error', d: String(err.message || err) }); }
  const u = await cuenta.sumar(gastados).catch(() => null);
  out({ t: 'done', tokens: gastados, hoy: u?.tokens });
  res.end();
}

async function manejar(req, res) {
  try {
    const url = new URL(req.url, 'http://x');
    const p = url.pathname;
    const CH = CHATS;
    if (req.method === 'GET' && STATIC[p]) {
      const [f, type] = STATIC[p];
      return send(res, 200, await fs.readFile(path.join(APP, f)), type);
    }
    if (p.startsWith('/files/') && req.method === 'GET') {
      const s = await getSettings(); const ws = path.resolve(s.workspace || path.join(ROOT, 'trabajos'));
      const f = path.resolve(ws, decodeURIComponent(p.slice(7)));
      if (!f.startsWith(ws)) return send(res, 403, 'no');
      const st = await fs.stat(f).catch(() => null); if (!st || !st.isFile()) return send(res, 404, 'No existe', 'text/plain');
      const ext = path.extname(f).toLowerCase();
      const MIME = { '.html': 'text/html', '.htm': 'text/html', '.css': 'text/css', '.js': 'text/javascript', '.mjs': 'text/javascript', '.json': 'application/json',
        '.png': 'image/png', '.jpg': 'image/jpeg', '.jpeg': 'image/jpeg', '.gif': 'image/gif', '.webp': 'image/webp', '.svg': 'image/svg+xml',
        '.mp4': 'video/mp4', '.webm': 'video/webm', '.mp3': 'audio/mpeg', '.wav': 'audio/wav', '.ogg': 'audio/ogg', '.txt': 'text/plain', '.md': 'text/plain' };
      const type = MIME[ext] || 'application/octet-stream';
      const range = req.headers.range && /bytes=(\d*)-(\d*)/.exec(req.headers.range);
      if (range) {
        const start = +range[1] || 0, end = range[2] ? +range[2] : st.size - 1;
        res.writeHead(206, { 'Content-Type': type, 'Content-Range': `bytes ${start}-${end}/${st.size}`, 'Accept-Ranges': 'bytes', 'Content-Length': end - start + 1 });
        return createReadStream(f, { start, end }).pipe(res);
      }
      res.writeHead(200, { 'Content-Type': type + (type.startsWith('text') ? '; charset=utf-8' : ''), 'Content-Length': st.size, 'Accept-Ranges': 'bytes', 'Cache-Control': 'no-store' });
      return createReadStream(f).pipe(res);
    }
    if (p === '/api/config' && req.method === 'GET') {
      const st = await getSettings();
      const stPub = { ...st, plan: (await cuenta.estado(st)).plan };
      if (stPub.cloud) stPub.cloud = { url: stPub.cloud.url || '', model: stPub.cloud.model || '', set: !!stPub.cloud.key };   // no mandamos la clave al navegador
      return send(res, 200, { models: MODELS, efforts: EFFORTS, plans: PLANS, settings: stPub, cuenta: await cuenta.estado(st), installed: await installedModels(), juego });
    }
    if (p === '/api/cuenta' && req.method === 'GET') return send(res, 200, await cuenta.estado(await getSettings()));
    if (p === '/api/version' && req.method === 'GET') return send(res, 200, { ...act.estado, local: await act.versionLocal() });
    // Precalentar: carga el modelo en la gráfica antes de que escribas, para que la 1ª respuesta no tarde
    if (p === '/api/warmup' && req.method === 'POST') {
      const b = await body(req);
      let m = MODELS.find(x => x.id === b.model);
      if (!m || m.id === 'nexo-auto') m = MODELS.find(x => x.id === 'nexo-chat');
      const base = m?.base || m?.id || 'nexo-chat';
      if (!calentando.has(base) && !juego.game) {   // no precalentar si estás jugando
        calentando.add(base);
        fetch(OLLAMA + '/api/generate', { method: 'POST', body: JSON.stringify({ model: base, prompt: '', keep_alive: '10m', options: { num_thread: CPU_THREADS } }) })
          .catch(() => {}).finally(() => setTimeout(() => calentando.delete(base), 20000));
      }
      return send(res, 200, { ok: true });
    }
    if (p === '/api/licencia' && req.method === 'POST') {
      const b = await body(req);
      if (b.generar) {
        const st = await getSettings(); if (!(await cuenta.estado(st)).propietario) return send(res, 403, { error: 'Solo el propietario puede crear licencias' });
        if (!LIMITES[b.generar]) return send(res, 400, { error: 'Plan no válido' });
        return send(res, 200, { codigo: cuenta.generarLicencia(b.generar, b.nombre || '', +b.dias || 0) });
      }
      const d = await cuenta.activar(b.codigo);
      return d ? send(res, 200, { ok: true, plan: d.plan }) : send(res, 400, { error: 'Código de licencia no válido o caducado' });
    }
    if (p === '/api/juego' && req.method === 'GET') return send(res, 200, juego);
    // Compartir Nexo con amigos (solo desde tu PC: la puerta de amigos no deja llegar aquí)
    if (p === '/api/stats' && req.method === 'GET') {
      if (!(await cuenta.estado(await getSettings())).propietario) return send(res, 403, { error: 'Solo el dueño' });
      return send(res, 200, await stats.totales());
    }
    if (p === '/api/memoria' && req.method === 'GET') return send(res, 200, await readMemoria());
    if (p === '/api/memoria' && req.method === 'POST') {
      const b = await body(req); let mem = await readMemoria();
      if (typeof b.add === 'string' && b.add.trim()) mem.push(b.add.trim().slice(0, 300));
      if (Number.isInteger(b.remove)) mem.splice(b.remove, 1);
      if (b.clear) mem = [];
      await writeMemoria(mem); return send(res, 200, mem);
    }
    if (p === '/api/subir' && req.method === 'POST') {
      const s = await getSettings(); const ws = s.workspace || path.join(ROOT, 'trabajos');
      const name = path.basename(decodeURIComponent(url.searchParams.get('nombre') || 'archivo')).replace(/[<>:"|?*]/g, '_') || 'archivo';
      const dir = path.join(ws, 'subidas'); await fs.mkdir(dir, { recursive: true });
      let dest = path.join(dir, name);
      for (let i = 2; await fs.access(dest).then(() => true, () => false); i++) dest = path.join(dir, name.replace(/(\.[^.]*)?$/, ` (${i})$1`));
      await new Promise((resolve, reject) => { const w = createWriteStream(dest); req.pipe(w); w.on('finish', resolve); w.on('error', reject); });
      return send(res, 200, { ruta: path.relative(ws, dest).replace(/\\/g, '/'), nombre: path.basename(dest) });
    }
    if (p === '/api/juego' && req.method === 'POST') {
      const b = await body(req);
      if (b.on) await pause('manual'); else resume();
      return send(res, 200, juego);
    }
    if (p === '/api/settings' && req.method === 'POST') {
      const b = await body(req); const s = await getSettings();
      if (b.plan && PLANS.some(x => x.id === b.plan)) {
        if (!(await cuenta.estado(s)).propietario) return send(res, 403, { error: 'Para cambiar de plan necesitas un código de licencia' });
        s.plan = b.plan;
      }
      if (b.model && MODELS.some(x => x.id === b.model)) s.model = b.model;
      if (b.effort && EFFORTS.some(x => x.id === b.effort)) s.effort = b.effort;
      if (typeof b.system === 'string') s.system = b.system.slice(0, 4000);
      if (typeof b.userName === 'string') s.userName = b.userName.slice(0, 40);
      if (['ask', 'auto'].includes(b.permisos)) s.permisos = b.permisos;
      if (typeof b.agent === 'boolean') s.agent = b.agent;
      if (typeof b.autoJuego === 'boolean') s.autoJuego = b.autoJuego;
      if (typeof b.workspace === 'string') s.workspace = b.workspace.trim() || undefined;
      if (typeof b.apagarEnJuegos === 'boolean') s.apagarEnJuegos = b.apagarEnJuegos;
      if (b.cloud && typeof b.cloud === 'object') {
        const prev = s.cloud || {};
        const key = (b.cloud.key === '__KEEP__' || b.cloud.key === undefined) ? (prev.key || '') : String(b.cloud.key || '').trim();
        s.cloud = { url: String(b.cloud.url || '').trim(), key, model: String(b.cloud.model || '').trim() };
      }
      await writeJSON(SETTINGS, s); return send(res, 200, s);
    }
    if (p === '/api/chat' && req.method === 'POST') return chat(req, res);
    if (p === '/api/approve' && req.method === 'POST') {
      const b = await body(req); const r = approvals.get(b.id);
      if (r) r(['si', 'siempre', 'no'].includes(b.decision) ? b.decision : 'no');
      return send(res, 200, { ok: !!r });
    }
    if (p === '/api/chats' && req.method === 'GET') {
      const list = (await allChats(CH)).map(c => ({ id: c.id, title: c.title, updated: c.updated, project: c.project || null }));
      return send(res, 200, list);
    }
    if (p === '/api/search' && req.method === 'GET') {
      const q = norm(url.searchParams.get('q') || '').trim(); if (!q) return send(res, 200, []);
      const out = [];
      for (const c of await allChats(CH)) {
        let snip = null;
        if (norm(c.title).includes(q)) snip = c.title;
        for (const m of c.messages || []) {
          if (snip && snip !== c.title) break;
          const t = String(m.content || ''); const i = norm(t).indexOf(q);
          if (i >= 0) { snip = (i > 40 ? '…' : '') + t.slice(Math.max(0, i - 40), i + 80).replace(/\s+/g, ' ') + '…'; break; }
        }
        if (snip) out.push({ id: c.id, title: c.title, snip, updated: c.updated });
        if (out.length >= 30) break;
      }
      return send(res, 200, out);
    }
    if (p === '/api/creaciones' && req.method === 'GET') {
      const s = await getSettings(); const ws = s.workspace || path.join(ROOT, 'trabajos');
      const files = []; await walk(ws, ws, files, 0);
      files.sort((a, b) => b.mtime - a.mtime);
      return send(res, 200, { ws, files: files.slice(0, 300) });
    }
    if (p === '/api/abrir' && req.method === 'POST') {
      const b = await body(req); const s = await getSettings(); const ws = s.workspace || path.join(ROOT, 'trabajos');
      const target = path.resolve(ws, String(b.ruta || ''));
      if (!target.startsWith(path.resolve(ws))) return send(res, 400, { error: 'Ruta fuera de la carpeta de trabajo' });
      spawn('explorer.exe', [b.carpeta ? '/select,' + target : target], { detached: true, windowsHide: true }).unref();
      return send(res, 200, { ok: true });
    }
    if (p === '/api/skills' && req.method === 'GET') {
      const s = await getSettings(); const off = s.skillsOff || [];
      return send(res, 200, (await loadSkills(SKILLS)).map(k => ({ name: k.name, cat: k.cat, claves: k.claves, on: !off.includes(k.name), mia: k.file.startsWith('99') })));
    }
    if (p === '/api/skills' && req.method === 'POST') {
      const b = await body(req); const s = await getSettings();
      if (b.toggle) {
        const off = new Set(s.skillsOff || []); b.on ? off.delete(b.toggle) : off.add(b.toggle);
        s.skillsOff = [...off]; await writeJSON(SETTINGS, s); return send(res, 200, { ok: true });
      }
      const name = norm(b.name || '').replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '').slice(0, 40);
      if (!name || !b.body) return send(res, 400, { error: 'Falta nombre o contenido' });
      const file = path.join(SKILLS, '99-mias.md');
      let txt = await fs.readFile(file, 'utf8').catch(() => '# Mis skills\n');
      txt += `\n## ${name}\nclaves: ${String(b.claves || name).replace(/\n/g, ' ')}\n${String(b.body).trim()}\n`;
      await fs.writeFile(file, txt, 'utf8'); return send(res, 200, { ok: true, name });
    }
    if (p === '/api/projects' && req.method === 'POST') {
      const b = await body(req); const s = await getSettings(); s.projects = s.projects || [];
      if (b.create) s.projects.push({ id: randomUUID(), name: String(b.create).slice(0, 40) });
      if (b.delete) { s.projects = s.projects.filter(x => x.id !== b.delete); for (const c of await allChats()) if (c.project === b.delete) { c.project = null; await writeJSON(path.join(CHATS, c.id + '.json'), c); } }
      if (b.rename) { const pr = s.projects.find(x => x.id === b.rename); if (pr) pr.name = String(b.name || pr.name).slice(0, 40); }
      await writeJSON(SETTINGS, s); return send(res, 200, s.projects);
    }
    if (p === '/api/chats' && req.method === 'POST') return send(res, 200, { id: randomUUID() });
    const mm = p.match(/^\/api\/chats\/([^/]+)$/);
    if (mm) {
      const id = safeId(mm[1]); if (!id) return send(res, 400, { error: 'id' });
      const file = path.join(CH, id + '.json');
      if (req.method === 'GET') { const c = await readJSON(file, null); return c ? send(res, 200, c) : send(res, 404, { error: 'No existe' }); }
      if (req.method === 'PUT') {
        const b = await body(req); const old = await readJSON(file, {});
        const c = { id, title: String(b.title || old.title || 'Chat nuevo').slice(0, 80), messages: b.messages || old.messages || [], updated: Date.now(),
          project: b.project !== undefined ? b.project : (old.project || null) };
        await writeJSON(file, c); return send(res, 200, { ok: true });
      }
      if (req.method === 'PATCH') {
        const b = await body(req); const c = await readJSON(file, null); if (!c) return send(res, 404, { error: 'No existe' });
        if (b.project !== undefined) c.project = b.project; if (b.title) c.title = String(b.title).slice(0, 80);
        await writeJSON(file, c); return send(res, 200, { ok: true });
      }
      if (req.method === 'DELETE') { await fs.rm(file, { force: true }); return send(res, 200, { ok: true }); }
    }
    send(res, 404, { error: 'No encontrado' });
  } catch (err) { console.error(err); if (!res.headersSent) send(res, 500, { error: String(err.message || err) }); else res.end(); }
}
const server = http.createServer(manejar);

// Si el puerto sigue ocupado (por ejemplo, justo después de una actualización), reintentar unos segundos
let intentos = 0;
server.on('error', e => { if (e.code === 'EADDRINUSE' && intentos++ < 30) setTimeout(() => server.listen(PORT, '127.0.0.1'), 500); else { console.error(e); process.exit(1); } });
server.listen(PORT, '127.0.0.1', () => console.log(`Nexo listo en http://127.0.0.1:${PORT}`));

// Actualizaciones automáticas (solo en las copias instaladas, nunca en la del propietario)
const act = crearActualizador(ROOT, APP);
async function buscarActualizacion() {
  if ((await cuenta.estado(await getSettings())).propietario) return;
  await act.comprobar(() => reiniciarServidor(fileURLToPath(import.meta.url)));
}
setTimeout(buscarActualizacion, 5000);
setInterval(buscarActualizacion, 3 * 3600 * 1000);
// Apagado automático mientras juegas (se puede quitar en Ajustes → Agente)
startWatcher(async () => (await getSettings()).apagarEnJuegos !== false);

// Contador anónimo: suma +1 por instalación y por día activo (nunca cuenta el PC del dueño)
setTimeout(async () => { try { stats.ping((await cuenta.estado(await getSettings())).propietario); } catch {} }, 8000);
