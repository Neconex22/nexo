# Bots, APIs e internet

## discord-bot
claves: discord, bot de discord, discord.js, servidor de discord
- `npm i discord.js`. Intents mínimos necesarios (Guilds, GuildMessages, MessageContent solo si lee mensajes).
- Slash commands registrados con REST. Token en archivo `.env` (nunca en el código ni en el chat).
- Estructura: index.mjs + carpeta commands/. Explica cómo crear la app en el Developer Portal.

## bot-twitch-chat
claves: twitch bot, chat de twitch, comandos de chat, tmi
- `npm i tmi.js`. Comandos con prefijo `!`. Cooldowns para evitar spam.
- Credenciales en `.env`. Respuestas cortas y con personalidad.

## web-scraping
claves: scraping, sacar datos de una web, extraer, descargar info
- Usa leer_web para páginas simples. Respeta robots.txt y no hagas muchas peticiones seguidas.
- Para datos estructurados, busca primero si la web tiene API.

## buscar-info
claves: busca, investiga, informacion, noticias, ultimo, actual, precio
- Usa buscar_web y después leer_web en 1-3 resultados fiables. Cita las fuentes (URL).
- Si no hay internet, dilo y responde con lo que sabes avisando de que puede estar desactualizado.

## apis-publicas
claves: api publica, clima, tiempo, cripto, datos en tiempo real
- Ejemplos sin clave: Open-Meteo (tiempo), REST Countries. Llama con fetch y muestra el JSON resumido.
- Si necesita clave, explica cómo conseguirla y guárdala en .env.

## automatizar-navegador
claves: automatizar navegador, puppeteer, playwright, rellenar web
- Playwright: `npm i playwright` y `npx playwright install chromium`. Solo para webs propias o permitidas.
- Nunca para saltarse captchas o crear cuentas en masa.

## servidor-local
claves: servidor local, localhost, servir web, abrir en el movil
- Servir una carpeta: `npx serve carpeta -l 5000` o un server.mjs con node:http.
- Para verlo en el móvil en la misma WiFi hay que escuchar en 0.0.0.0 y abrir el puerto en el firewall (pide permiso).

## json-config
claves: json, configuracion, config, ajustes, archivo de datos
- JSON válido (comillas dobles, sin comas finales). Valida leyéndolo con `Get-Content x.json | ConvertFrom-Json`.

## chatbot-web
claves: chatbot, chat en mi web, asistente web, ia en mi web
- Interfaz de chat en HTML que llame a Nexo/Ollama en `http://127.0.0.1:11434/api/chat` (solo funciona en este PC).
- Streaming leyendo el body por partes. Explica que para internet haría falta un servidor.

## extension-navegador
claves: extension, extension de chrome, extension de brave, addon
- Manifest V3: manifest.json + popup.html + popup.js. Cargar en brave://extensions → Modo desarrollador → Cargar descomprimida.
