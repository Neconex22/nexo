﻿# Variables de Nexo: todo vive dentro de esta carpeta
$N = $PSScriptRoot
$env:OLLAMA_MODELS          = "$N\models"
$env:OLLAMA_HOST            = "127.0.0.1:11434"
$env:OLLAMA_FLASH_ATTENTION = "1"
$env:OLLAMA_KV_CACHE_TYPE   = "q8_0"
$env:OLLAMA_NUM_PARALLEL    = "1"
$env:OLLAMA_MAX_LOADED_MODELS = "1"
# Usar como maximo ~75% de la grafica: deja 2 GB de los 8 GB libres
$env:OLLAMA_GPU_OVERHEAD    = "2147483648"
$env:OLLAMA_KEEP_ALIVE      = "5m"
$OLLAMA = "$N\ollama\ollama.exe"

function Start-NexoOllama {
  try { Invoke-RestMethod "http://127.0.0.1:11434/api/version" -TimeoutSec 2 | Out-Null; return } catch {}
  $p = Start-Process $OLLAMA -ArgumentList "serve" -WindowStyle Hidden -PassThru
  try { $p.PriorityClass = 'BelowNormal' } catch {}
  for ($i=0; $i -lt 60; $i++) {
    Start-Sleep 1
    try { Invoke-RestMethod "http://127.0.0.1:11434/api/version" -TimeoutSec 2 | Out-Null; return } catch {}
  }
  throw "Ollama no arranca"
}
