# Web: páginas profesionales

## web-landing
claves: landing, pagina, web, sitio, website, home, portada
Para una landing o web completa:
- PARTE DE LA PLANTILLA PROFESIONAL: usa `usar_plantilla` con "landing-creador.html" y destino "carpeta/index.html". Después llama a `rellenar_plantilla` con TODOS los huecos rellenados con contenido real y concreto del tema (y "color" con un color de marca que encaje). Si quedan huecos, vuelve a llamar. Luego probar_web y abrir.
- Estructura: header con logo y menú, hero (titular claro + subtítulo + 1 botón principal), secciones de beneficios, prueba social, CTA final y footer.
- Un único `index.html` con `<style>` y `<script>` dentro salvo que pidan varios archivos. Debe abrir con doble clic sin servidor.
- Usa HTML semántico: header, nav, main, section, footer. Etiqueta `<meta name="viewport">` siempre.
- Textos reales y concretos del tema (nunca "Lorem ipsum" ni "Bienvenido a nuestra web").
- Al terminar ábrela con la herramienta abrir.

## web-diseno-pro
claves: bonita, profesional, moderna, diseño, estilo, elegante, pro
Diseño que parece hecho por un estudio:
- Paleta: 1 color de marca + neutros (fondo, superficie, texto, texto suave). Define todo en variables CSS `:root`.
- Tipografía: máximo 2 familias. Títulos grandes (clamp(2.2rem, 5vw, 4.5rem)), interlineado 1.1 en títulos y 1.6 en texto.
- Espaciado generoso y consistente (múltiplos de 8px). Anchura de lectura máx. 70ch.
- Jerarquía clara: un solo botón principal por sección.
- Bordes redondeados coherentes (todos 12px, por ejemplo) y sombras suaves, nunca negras al 50%.

## web-responsive
claves: movil, responsive, adaptable, celular, tablet
- Mobile first: escribe el CSS para móvil y amplía con `@media (min-width: 768px)` y `(min-width: 1100px)`.
- Usa CSS Grid y Flexbox con `gap`; nada de anchos fijos en px para contenedores (usa max-width + width:100%).
- Imágenes con `max-width:100%; height:auto`. Menú hamburguesa en móvil.
- Botones y enlaces táctiles de al menos 44px de alto.

## web-animaciones
claves: animacion, animada, efectos, scroll, hover, transicion
- Transiciones de 150-300ms con `ease-out`. Animar solo transform y opacity (rendimiento).
- Aparición al hacer scroll con IntersectionObserver añadiendo una clase `.visible`.
- Respeta `@media (prefers-reduced-motion: reduce)`.
- Hover sutil: subir 2-4px y sombra un poco mayor. Nada de animaciones infinitas que distraigan.

## web-formularios
claves: formulario, contacto, registro, login, input
- Cada input con `<label>`, tipo correcto (email, tel, number) y `autocomplete`.
- Validación con atributos HTML (required, minlength, pattern) + mensajes claros en español.
- Estados focus visibles. Botón con texto de acción ("Enviar mensaje", no "Submit").
- Sin backend: muestra un mensaje de "¡Enviado!" en JS o usa mailto. Avisa de que para recibirlos de verdad hace falta un servicio.

## web-seo
claves: seo, google, posicionamiento, meta, buscadores
- `<title>` único (50-60 caracteres) y `<meta name="description">` (150-160).
- Un solo `<h1>`, luego h2/h3 en orden. Atributo alt descriptivo en imágenes.
- Open Graph (og:title, og:description, og:image) para que se vea bien al compartir.
- `lang="es"` en `<html>`. URLs y nombres de archivo en minúsculas con guiones.

## web-tienda
claves: tienda, ecommerce, productos, carrito, comprar, precio
- Tarjetas de producto: imagen, nombre, precio grande, botón "Añadir al carrito".
- Carrito en JS guardado en localStorage con contador en el header.
- Precios con formato español: `new Intl.NumberFormat('es-ES',{style:'currency',currency:'EUR'})`.
- Página de producto con galería, descripción, envío y devoluciones. Avisa de que los pagos reales requieren una pasarela (Stripe...) y un titular adulto.

## web-portfolio
claves: portfolio, portafolio, cv, curriculum, personal, streamer, creador
- Hero con nombre, qué haces en una frase y foto/avatar.
- Sección de trabajos/vídeos en grid con miniaturas; enlaces a redes (YouTube, Twitch, TikTok) con iconos SVG en línea.
- Sección "Sobre mí" breve y un contacto claro. Estilo coherente con la marca personal.

## web-dashboard
claves: dashboard, panel, estadisticas, graficas, admin
- Layout: barra lateral + cabecera + grid de tarjetas KPI + gráficas + tabla.
- Gráficas con `<canvas>` dibujadas a mano o SVG; sin librerías externas si debe funcionar offline.
- Números grandes con etiqueta pequeña y variación (+12% en verde, -3% en rojo).

## web-varios-archivos
claves: proyecto web, carpetas, css aparte, js aparte, estructura
Proyecto ordenado:
```
mi-web/
  index.html
  css/estilos.css
  js/app.js
  img/
```
- Rutas relativas (`css/estilos.css`). Crea todos los archivos con escribir_archivo y luego abre index.html.
- Si usa módulos ES o fetch de JSON local, necesita servidor: `npx serve mi-web` o `python -m http.server`.
