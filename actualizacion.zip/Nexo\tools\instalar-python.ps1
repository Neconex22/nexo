﻿# Instala Python 3.12 portable dentro de nexo\tools (no toca Windows)
$ErrorActionPreference = "Stop"
$T = $PSScriptRoot
New-Item -ItemType Directory -Force "$T\uv", "$T\python" | Out-Null
if (-not (Test-Path "$T\uv\uv.exe")) {
  curl.exe -L --fail -o "$T\uv\uv.zip" "https://github.com/astral-sh/uv/releases/latest/download/uv-x86_64-pc-windows-msvc.zip"
  tar.exe -xf "$T\uv\uv.zip" -C "$T\uv"; Remove-Item "$T\uv\uv.zip"
}
$env:UV_PYTHON_INSTALL_DIR = "$T\python"
$env:UV_CACHE_DIR = "$T\..\cache\uv"
& "$T\uv\uv.exe" python install 3.12 --no-bin
$py = Get-ChildItem "$T\python" -Recurse -Filter python.exe | Select-Object -First 1
Get-ChildItem $py.Directory.FullName -Recurse -Filter EXTERNALLY-MANAGED -ErrorAction SilentlyContinue | Remove-Item -Force
& $py.FullName -m ensurepip --upgrade
& $py.FullName -m pip --version
"PYTHON: " + $py.FullName
