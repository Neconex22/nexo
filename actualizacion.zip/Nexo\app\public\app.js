// Nexo - interfaz
const $ = s => document.querySelector(s);
const api = async (url, opt = {}) => {
  const r = await fetch(url, { headers: { 'Content-Type': 'application/json' }, ...opt, body: opt.body ? JSON.stringify(opt.body) : undefined });
  if (!r.ok) throw new Error((await r.json().catch(() => ({}))).error || r.statusText);
  return r.json();
};
let cfg, settings, chatId = null, messages = [], ctrl = null, pendingImgs = [];

marked.setOptions({ gfm: true, breaks: true });
function md(text) {
  const html = DOMPurify.sanitize(marked.parse(text || ''));
  const div = document.createElement('div'); div.innerHTML = html;
  div.querySelectorAll('pre > code').forEach(code => {
    const lang = (code.className.match(/language-(\S+)/) || [])[1] || '';
    try {
      if (lang && hljs.getLanguage(lang)) code.innerHTML = hljs.highlight(code.textContent, { language: lang }).value;
      else code.innerHTML = hljs.highlightAuto(code.textContent).value;
    } catch {}
    code.classList.add('hljs');
    const box = document.createElement('div'); box.className = 'codebox';
    box.innerHTML = `<div class="ch"><span>${lang || 'código'}</span><button class="copy">Copiar</button></div>`;
    const pre = code.parentElement; pre.replaceWith(box); box.appendChild(pre);
  });
  return div.innerHTML;
}
document.addEventListener('click', e => {
  if (e.target.matches('.codebox .copy')) {
    navigator.clipboard.writeText(e.target.closest('.codebox').querySelector('code').textContent);
    e.target.textContent = '¡Copiado!'; setTimeout(() => e.target.textContent = 'Copiar', 1500);
  }
});
function toast(t) { const el = $('#toast'); el.textContent = t; el.classList.add('show'); clearTimeout(el._t); el._t = setTimeout(() => el.classList.remove('show'), 2600); }
const plan = () => cfg.plans.find(p => p.id === settings.plan) || cfg.plans[0];
const model = id => cfg.models.find(m => m.id === (id || settings.model));
const effort = id => cfg.efforts.find(e => e.id === (id || settings.effort));
const planFor = (kind, id) => cfg.plans.find(p => p[kind].includes(id));
const installed = id => { const b = cfg.models.find(m => m.id === id)?.base || id; return b === 'nexo-auto' || !cfg.installed || cfg.installed.includes(b); };
const kfmt = n => n >= 1e6 ? (n / 1e6).toFixed(1).replace('.0', '') + 'M' : n >= 1000 ? Math.round(n / 1000) + 'k' : String(n);
function tokensText() {
  const t = cfg.cuenta?.tokens; if (!t) return '';
  return t.limite === null ? '∞ tokens' : `${kfmt(t.usados)} / ${kfmt(t.limite)} tokens hoy`;
}
async function refreshCuenta() { try { cfg.cuenta = await api('/api/cuenta'); renderSide(); } catch {} }

// ---------- Config ----------
async function loadConfig() {
  cfg = await api('/api/config'); settings = cfg.settings;
  const p = plan();
  if (!p.models.includes(settings.model)) settings.model = p.models[0];
  if (!p.efforts.includes(settings.effort)) settings.effort = p.efforts[p.efforts.length - 1];
  renderPickers(); renderSide(); renderStatus();
}
function renderStatus() {
  const s = $('#status');
  if (!cfg.installed) { s.textContent = '● Motor apagado'; s.className = 'status off'; }
  else { const n = cfg.models.filter(m => installed(m.id)).length; s.textContent = `● ${n}/${cfg.models.length} modelos listos`; s.className = 'status'; }
}
function renderSide() {
  const p = plan(); const name = settings.userName || 'Tú';
  $('#userName').textContent = name; $('#avatar').textContent = name[0].toUpperCase();
  $('#planBadge').textContent = `${cfg.cuenta?.propietario ? '👑 ' : ''}${cfg.cuenta?.demo ? 'Demo' : 'Plan ' + p.name} · ${tokensText()}`; $('#planBadge').style.color = p.color;
  $('#greet').textContent = settings.userName ? `¿En qué te ayudo hoy, ${settings.userName}?` : '¿En qué te ayudo hoy?';
}
function renderPickers() {
  const p = plan(); const m = model(); const e = effort();
  $('#modelLabel').textContent = m.name; $('#effortLabel').textContent = e.name;
  const opt = (kind, x, sel) => {
    const locked = !p[kind].includes(x.id); const lp = planFor(kind, x.id);
    const miss = kind === 'models' && !installed(x.id);
    return `<button class="opt ${sel ? 'sel' : ''} ${locked ? 'locked' : ''} ${miss ? 'missing' : ''}" data-kind="${kind}" data-id="${x.id}" data-plan="${cfg.cuenta?.demo ? 'Próximamente' : (lp?.name || '')}">
      <span class="n">${x.name}</span><span class="d">${x.desc}</span></button>`;
  };
  $('#modelMenu').innerHTML =
    cfg.models.filter(x => x.tipo === 'auto').map(x => opt('models', x, x.id === m.id)).join('') +
    '<div class="grp">💬 Hablar</div>' + cfg.models.filter(x => x.tipo === 'chat').map(x => opt('models', x, x.id === m.id)).join('') +
    '<div class="grp">💻 Programar</div>' + cfg.models.filter(x => x.tipo === 'code').map(x => opt('models', x, x.id === m.id)).join('');
  $('#effortMenu').innerHTML = '<div class="grp">Nivel de esfuerzo</div>' + cfg.efforts.map(x => opt('efforts', x, x.id === e.id)).join('');
}
const agentOn = () => !!model().tools;

$('#btnSaveAgent').onclick = () => {
  saveSettings({ permisos: $('#setPermisos').value, workspace: $('#setWorkspace').value.trim() });
  $('#modal').classList.add('hidden'); toast('Ajustes del agente guardados');
};
function saveSettings(obj) { Object.assign(settings, obj); api('/api/settings', { method: 'POST', body: obj }).catch(() => {}); }

document.addEventListener('click', e => {
  const o = e.target.closest('.opt');
  if (o) {
    const { kind, id } = o.dataset;
    if (o.classList.contains('locked')) { closeMenus(); openModal('plans'); toast(cfg.cuenta?.demo ? 'Disponible en la versión completa (próximamente)' : `Disponible en el plan ${o.dataset.plan}`); return; }
    saveSettings(kind === 'models' ? { model: id } : { effort: id });
    renderPickers(); closeMenus(); $('#input').focus(); return;
  }
  if (e.target.closest('#modelBtn')) return toggleMenu('#modelMenu');
  if (e.target.closest('#effortBtn')) return toggleMenu('#effortMenu');
  if (!e.target.closest('.menu')) closeMenus();
});
function toggleMenu(sel) { const open = $(sel).classList.contains('open'); closeMenus(); if (!open) $(sel).classList.add('open'); }
function closeMenus() { document.querySelectorAll('.menu').forEach(m => m.classList.remove('open')); }

// ---------- Chats y proyectos ----------
let chatCache = [], openProjects = new Set(JSON.parse(localStorage.getItem('nexoOpenProj') || '[]'));
const chatItem = c => `<div class="chat-item ${c.id === chatId ? 'active' : ''}" data-id="${c.id}">
  <span class="t">${escapeHTML(c.title)}</span><button class="del" title="Opciones">⋯</button></div>`;
async function renderChatList() {
  chatCache = await api('/api/chats');
  const projects = settings.projects || [];
  const ids = new Set(projects.map(p => p.id));
  $('#projectList').innerHTML = projects.length ? projects.map(p => {
    const cs = chatCache.filter(c => c.project === p.id);
    return `<div class="proj ${openProjects.has(p.id) ? 'open' : ''}" data-pid="${p.id}">
      <div class="proj-head"><span class="arrow">▶</span><span class="pn">📁 ${escapeHTML(p.name)}</span>
        <button class="mini pnew" title="Nuevo chat en este proyecto">＋</button><button class="mini pmenu" title="Opciones">⋯</button></div>
      <div class="proj-chats">${cs.map(chatItem).join('') || '<div class="proj-empty">Sin chats todavía</div>'}</div></div>`;
  }).join('') : '<div class="proj-empty">Agrupa chats por tema con ＋</div>';
  $('#chatList').innerHTML = chatCache.filter(c => !c.project || !ids.has(c.project)).map(chatItem).join('');
}
const escapeHTML = s => String(s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
let newChatProject = null;
$('#side').addEventListener('click', async e => {
  const ph = e.target.closest('.proj-head');
  if (ph) {
    const pid = ph.parentElement.dataset.pid;
    if (e.target.closest('.pnew')) { newChat(); newChatProject = pid; openProjects.add(pid); saveOpen(); renderChatList(); toast('Nuevo chat en el proyecto'); return; }
    if (e.target.closest('.pmenu')) return projectMenu(pid, e);
    openProjects.has(pid) ? openProjects.delete(pid) : openProjects.add(pid); saveOpen();
    ph.parentElement.classList.toggle('open'); return;
  }
  const item = e.target.closest('.chat-item'); if (!item) return;
  if (e.target.closest('.del')) return chatMenu(item.dataset.id, e);
  openChat(item.dataset.id);
});
const saveOpen = () => localStorage.setItem('nexoOpenProj', JSON.stringify([...openProjects]));
function showCtx(html, e) {
  const m = $('#ctxMenu'); m.innerHTML = html; m.classList.remove('hidden');
  const r = e.target.getBoundingClientRect();
  m.style.left = Math.min(r.left, innerWidth - 210) + 'px'; m.style.top = Math.min(r.bottom + 4, innerHeight - m.offsetHeight - 8) + 'px';
}
document.addEventListener('click', e => { if (!e.target.closest('#ctxMenu') && !e.target.closest('.del') && !e.target.closest('.pmenu')) $('#ctxMenu').classList.add('hidden'); });
function chatMenu(id, e) {
  const c = chatCache.find(x => x.id === id); const projects = settings.projects || [];
  showCtx(`<button data-a="rename">✏️ Renombrar</button><div class="sep"></div><div class="lbl">Mover a proyecto</div>
    ${projects.map(p => `<button data-a="move" data-p="${p.id}">${c?.project === p.id ? '✓ ' : ''}📁 ${escapeHTML(p.name)}</button>`).join('')}
    <button data-a="move" data-p="">${!c?.project ? '✓ ' : ''}Sin proyecto</button><button data-a="newproj">＋ Nuevo proyecto…</button>
    <div class="sep"></div><button data-a="del" style="color:#ff6b6b">🗑 Borrar chat</button>`, e);
  $('#ctxMenu').onclick = async ev => {
    const b = ev.target.closest('button'); if (!b) return; $('#ctxMenu').classList.add('hidden');
    if (b.dataset.a === 'rename') { const t = prompt('Nuevo nombre del chat:', c?.title || ''); if (t) await api('/api/chats/' + id, { method: 'PATCH', body: { title: t } }); if (id === chatId && t) $('#chatTitle').textContent = t; }
    if (b.dataset.a === 'move') { await api('/api/chats/' + id, { method: 'PATCH', body: { project: b.dataset.p || null } }); if (b.dataset.p) { openProjects.add(b.dataset.p); saveOpen(); } }
    if (b.dataset.a === 'newproj') { const pid = await createProject(); if (pid) await api('/api/chats/' + id, { method: 'PATCH', body: { project: pid } }); }
    if (b.dataset.a === 'del') { if (!confirm('¿Borrar este chat?')) return; await api('/api/chats/' + id, { method: 'DELETE' }); if (id === chatId) newChat(); }
    renderChatList();
  };
}
function projectMenu(pid, e) {
  showCtx(`<button data-a="rename">✏️ Renombrar proyecto</button><button data-a="del" style="color:#ff6b6b">🗑 Quitar proyecto (los chats se quedan)</button>`, e);
  $('#ctxMenu').onclick = async ev => {
    const b = ev.target.closest('button'); if (!b) return; $('#ctxMenu').classList.add('hidden');
    const pr = (settings.projects || []).find(p => p.id === pid);
    if (b.dataset.a === 'rename') { const n = prompt('Nombre del proyecto:', pr?.name || ''); if (n) settings.projects = await api('/api/projects', { method: 'POST', body: { rename: pid, name: n } }); }
    if (b.dataset.a === 'del' && confirm('¿Quitar el proyecto? Los chats pasarán a Recientes.')) settings.projects = await api('/api/projects', { method: 'POST', body: { delete: pid } });
    renderChatList();
  };
}
async function createProject() {
  const n = prompt('Nombre del proyecto (ej: Mi canal, Juegos, Webs):'); if (!n) return null;
  settings.projects = await api('/api/projects', { method: 'POST', body: { create: n } });
  const p = settings.projects[settings.projects.length - 1]; openProjects.add(p.id); saveOpen(); renderChatList(); return p.id;
}
$('#btnNewProject').onclick = () => createProject();
async function openChat(id) {
  if (ctrl) ctrl.abort();
  if (innerWidth < 760) $('#app').classList.add('collapsed');
  const c = await api('/api/chats/' + id); chatId = c.id; messages = c.messages;
  $('#chatTitle').textContent = c.title; renderMessages(); renderChatList();
}
function newChat() {
  if (ctrl) ctrl.abort();
  chatId = null; messages = []; newChatProject = null; $('#chatTitle').textContent = 'Nuevo chat'; renderMessages(); renderChatList(); $('#input').focus();
}
async function saveChat() {
  let isNew = false;
  if (!chatId) { chatId = (await api('/api/chats', { method: 'POST' })).id; isNew = true; }
  const first = messages.find(m => m.role === 'user')?.content || 'Chat nuevo';
  const title = chatCache.find(c => c.id === chatId)?.title || first.replace(/\s+/g, ' ').slice(0, 48);
  $('#chatTitle').textContent = title;
  const body = { title, messages }; if (isNew && newChatProject) { body.project = newChatProject; newChatProject = null; }
  await api('/api/chats/' + chatId, { method: 'PUT', body }); renderChatList();
}
$('#btnNew').onclick = newChat;

// ---------- Mensajes (con herramientas) ----------
const TOOL_LABEL = { listar: 'Mirar carpeta', leer_archivo: 'Leer archivo', crear_carpeta: 'Crear carpeta', escribir_archivo: 'Escribir archivo',
  editar_archivo: 'Editar archivo', mover: 'Mover', borrar: 'Borrar (Papelera)', ejecutar: 'Ejecutar comando', abrir: 'Abrir',
  buscar_web: 'Buscar en la web', leer_web: 'Leer página web', crear_exe: 'Crear .exe', compilar_csharp: 'Compilar programa', probar_web: 'Probar en el navegador', recordar: 'Recordar', olvidar: 'Olvidar', transcribir: 'Transcribir voz', usar_plantilla: 'Usar plantilla', rellenar_plantilla: 'Rellenar textos' };
const STATUS = { wait: '⏳', ask: '✋ Esperando permiso', running: '<span class="spin"></span>', ok: '✓', fail: '✕' };
const argSummary = a => a.dato || a.texto || a.ruta || a.comando || a.consulta || a.url || a.archivo || (a.plantilla ? `${a.plantilla} → ${a.destino}` : '') || (a.carpeta && a.nombre ? `${a.carpeta} → ${a.nombre}.exe` : a.carpeta) || (a.origen ? `${a.origen} → ${a.destino}` : '') || '';

function textOf(m) { return m.parts ? m.parts.filter(p => p.type === 'text').map(p => p.text).join('').trim() : m.content; }
function historyOf(m) {
  if (m.role === 'user') return m.content + (m.files?.length ? `\n\n[El usuario ha adjuntado estos archivos, ya guardados en tu carpeta de trabajo: ${m.files.map(f => '"' + f.ruta + '"').join(', ')}]` : '');
  if (m.role !== 'assistant' || !m.parts) return m.content;
  return m.parts.map(p => p.type === 'text' ? p.text : `\n[Acción: ${p.name}(${argSummary(p.args)}) → ${p.status === 'ok' ? 'hecho' : 'falló'}]\n`).join('').trim();
}

function renderMessages() {
  $('#welcome').classList.toggle('hidden', messages.length > 0);
  $('#messages').innerHTML = '';
  messages.forEach((m, i) => $('#messages').appendChild(msgEl(m, i)));
  scrollDown(true);
}
function toolHTML(p) {
  const st = p.status || 'wait';
  return `<div class="tool ${st}" data-id="${p.id}">
    <details><summary class="th"><span class="ti">${p.icon || '🔧'}</span><span class="tn">${TOOL_LABEL[p.name] || p.name}</span>
      <code class="ta">${escapeHTML(argSummary(p.args || {}))}</code><span class="ts">${STATUS[st]}</span></summary>
      <div class="tbody">${p.name === 'escribir_archivo' && p.args?.contenido ? `<div class="tl">Contenido</div><pre>${escapeHTML(p.args.contenido)}</pre>` :
        `<div class="tl">Datos</div><pre>${escapeHTML(JSON.stringify(p.args, null, 1))}</pre>`}
      ${p.result ? `<div class="tl">Resultado</div><pre>${escapeHTML(p.result)}</pre>` : ''}</div></details>
    ${st === 'ask' ? `<pre class="askcmd">${escapeHTML(argSummary(p.args || {}))}</pre><div class="askbar"><span>¿Dejas que Nexo haga esto?</span>
      <button data-d="si" class="ok">Permitir</button><button data-d="siempre">Permitir todo en esta respuesta</button><button data-d="no" class="no">Denegar</button></div>` : ''}
  </div>`;
}
function planHTML(p, live) {
  const pasos = Array.isArray(p.args?.pasos) ? p.args.pasos : String(p.args?.pasos || '').split(/\n|;/).filter(Boolean);
  const done = Math.min(+p.args?.completados || 0, pasos.length);
  return `<div class="planbox"><div class="ph"><span>📋 Plan</span><span>${done}/${pasos.length}</span></div>${pasos.map((s, i) =>
    `<div class="pi ${i < done ? 'done' : (i === done && live ? 'now' : '')}"><span class="dot">${i < done ? '✓' : ''}</span>${escapeHTML(s)}</div>`).join('')}</div>`;
}
function bodyHTML(m, live) {
  const parts = m.parts || [{ type: 'text', text: m.content }];
  // Solo se muestra el plan mas reciente, en la posicion del primero
  const plans = parts.filter(p => p.type === 'tool' && p.name === 'plan');
  const lastPlan = plans[plans.length - 1]; let planShown = false;
  return parts.map(p => {
    if (p.type === 'tool' && p.name === 'plan') { if (planShown) return ''; planShown = true; return planHTML(lastPlan, live); }
    return p.type === 'tool' ? toolHTML(p) : (p.text.trim() ? `<div class="content">${md(p.text)}</div>` : '');
  }).join('');
}
function msgEl(m, i) {
  const el = document.createElement('div'); el.className = 'msg ' + (m.role === 'user' ? 'user' : 'bot');
  if (m.role === 'user') {
    el.innerHTML = `<div class="bubble">${escapeHTML(m.content)}${m.files?.length ? '<div class="fchips">' + m.files.map(f => `<span class="fchip">📄 ${escapeHTML(f.nombre)}</span>`).join('') + '</div>' : ''}${m.images?.length ? '<div class="imgs">' + m.images.map(s => `<img src="${s}">`).join('') + '</div>' : ''}</div>`;
    return el;
  }
  const mm = model(m.model); const ee = effort(m.effort);
  const nTools = (m.parts || []).filter(p => p.type === 'tool').length;
  el.innerHTML = `<img class="ico" src="/logo.svg"><div class="body">
    <div class="meta">${m.auto ? 'Nexo Auto → ' : ''}${mm?.name || 'Nexo'} ·${ee?.name || ''}${nTools ? ` · ${nTools} acciones` : ''}${m.speed ? ` · ${m.speed} t/s` : ''}${m.secs ? ` · ${m.secs}s` : ''}</div>
    ${m.skills?.length ? `<div class="skills-used">✦ Skills: ${m.skills.map(s => `<b>${escapeHTML(s)}</b>`).join(', ')}</div>` : ''}
    ${m.thinking ? `<details class="think"><summary>Pensamiento${m.thinkSecs ? ` (${m.thinkSecs}s)` : ''}</summary><div class="tt"></div></details>` : ''}
    <div class="parts ${m.error ? 'err' : ''}"></div>
    <div class="actions"><button data-a="copy">Copiar</button>${i === messages.length - 1 ? '<button data-a="regen">↻ Regenerar</button>' : ''}</div></div>`;
  if (m.thinking) el.querySelector('.tt').textContent = m.thinking;
  el.querySelector('.parts').innerHTML = m.error ? `<div class="content err">${escapeHTML(m.content)}</div>` + bodyHTML({ parts: m.parts || [] }) : bodyHTML(m);
  el.querySelector('[data-a="copy"]').onclick = () => { navigator.clipboard.writeText(textOf(m)); toast('Respuesta copiada'); };
  const rg = el.querySelector('[data-a="regen"]'); if (rg) rg.onclick = () => { messages.pop(); renderMessages(); generate(); };
  return el;
}
document.addEventListener('click', async e => {
  const b = e.target.closest('.askbar button'); if (!b) return;
  const card = b.closest('.tool'); const id = card.dataset.id;
  card.querySelector('.askbar').innerHTML = '<span>Enviando…</span>';
  await api('/api/approve', { method: 'POST', body: { id, decision: b.dataset.d } }).catch(() => {});
});

let stick = true;
$('#scroll').addEventListener('scroll', () => { const s = $('#scroll'); stick = s.scrollHeight - s.scrollTop - s.clientHeight < 80; });
function scrollDown(force) { if (force || stick) { const s = $('#scroll'); s.style.scrollBehavior = 'auto'; s.scrollTop = s.scrollHeight; s.style.scrollBehavior = ''; } }

async function sendMessage(text) {
  text = (text ?? $('#input').value).trim();
  if ((!text && !pendingImgs.length && !pendingFiles.length) || ctrl) return;
  if (pendingFiles.some(f => f.subiendo)) return toast('Espera a que terminen de subirse los archivos');
  const m = model();
  if (!installed(m.id)) return toast(`${m.name} todavía se está descargando`);
  const files = pendingFiles.filter(f => f.ruta).map(f => ({ nombre: f.nombre, ruta: f.ruta }));
  messages.push({ role: 'user', content: text || 'Mira los archivos que te he pasado.', images: pendingImgs.length ? [...pendingImgs] : undefined, files: files.length ? files : undefined });
  pendingImgs = []; pendingFiles = []; renderAttachments();
  $('#input').value = ''; autosize(); renderMessages(); await generate();
}
async function generate() {
  const m = model(), e = effort();
  const agent = agentOn();
  const bot = { role: 'assistant', content: '', thinking: '', parts: [], model: m.id, effort: e.id, agent };
  messages.push(bot);
  const el = msgEl(bot, messages.length - 1); $('#messages').appendChild(el); scrollDown(true);
  const partsEl = el.querySelector('.parts');
  partsEl.innerHTML = '<span class="thinking-dot">Nexo está pensando…</span>';
  setSending(true);
  const t0 = Date.now(); let tThinkEnd = null; let thinkBox = null; let timer = 0;
  const tools = {};
  const lastText = () => { let p = bot.parts[bot.parts.length - 1]; if (!p || p.type !== 'text') { p = { type: 'text', text: '' }; bot.parts.push(p); } return p; };
  const paint = () => {
    timer = 0;
    if (bot.thinking && !thinkBox) {
      thinkBox = document.createElement('details'); thinkBox.className = 'think'; thinkBox.open = true;
      thinkBox.innerHTML = '<summary>Pensando<span class="thinking-dot">…</span></summary><div class="tt"></div>';
      partsEl.before(thinkBox);
    }
    if (thinkBox) { const tt = thinkBox.querySelector('.tt'); tt.textContent = bot.thinking; tt.scrollTop = tt.scrollHeight; }
    if (thinkBox && tThinkEnd && !thinkBox._closed) { thinkBox._closed = true; thinkBox.open = false; thinkBox.querySelector('summary').textContent = 'Pensamiento'; }
    if (bot.parts.length) {
      const open = new Set([...partsEl.querySelectorAll('.tool details[open]')].map(d => d.closest('.tool').dataset.id));
      partsEl.innerHTML = bodyHTML(bot, true);
      open.forEach(id => partsEl.querySelector(`.tool[data-id="${id}"] details`)?.setAttribute('open', ''));
      const lastC = partsEl.querySelector('.content:last-child'); if (lastC) lastC.classList.add('cursor');
    }
    scrollDown();
  };
  const repaint = (now) => { if (now) { clearTimeout(timer); paint(); } else if (!timer) timer = setTimeout(paint, 50); };
  ctrl = new AbortController();
  try {
    const r = await fetch('/api/chat', { method: 'POST', signal: ctrl.signal, headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ model: m.id, effort: e.id, agent,
        messages: messages.slice(0, -1).map(x => ({ role: x.role, content: historyOf(x), images: x.images })) }) });
    if (!r.ok) throw new Error((await r.json().catch(() => ({}))).error || 'Error');
    const reader = r.body.getReader(); const dec = new TextDecoder(); let buf = '';
    while (true) {
      const { value, done } = await reader.read(); if (done) break;
      buf += dec.decode(value, { stream: true }); let i;
      while ((i = buf.indexOf('\n')) >= 0) {
        const line = buf.slice(0, i); buf = buf.slice(i + 1); if (!line.trim()) continue;
        const ev = JSON.parse(line); let now = false;
        if (ev.t === 'think') bot.thinking += ev.d;
        else if (ev.t === 'text') { if (!tThinkEnd) tThinkEnd = Date.now(); lastText().text += ev.d; }
        else if (ev.t === 'speed') { if (ev.speed) bot.speed = ev.speed; }
        else if (ev.t === 'auto') { bot.model = ev.model; bot.auto = true; const meta = el.querySelector('.meta'); if (meta) meta.textContent = `Nexo Auto → ${ev.name} · ${e.name}`; }
        else if (ev.t === 'untext') { const lp = bot.parts[bot.parts.length - 1]; if (lp?.type === 'text') bot.parts.pop(); now = true; }
        else if (ev.t === 'skills') { bot.skills = ev.names; const meta = el.querySelector('.meta'); meta.insertAdjacentHTML('afterend', `<div class="skills-used">✦ Skills: ${ev.names.map(s => `<b>${escapeHTML(s)}</b>`).join(', ')}</div>`); }
        else if (ev.t === 'tool') { if (!tThinkEnd) tThinkEnd = Date.now(); const p = { type: 'tool', id: ev.id, name: ev.name, icon: ev.icon, args: ev.args, status: 'wait' }; tools[ev.id] = p; bot.parts.push(p); now = true; }
        else if (ev.t === 'ask') { tools[ev.id].status = 'ask'; now = true; }
        else if (ev.t === 'running') { tools[ev.id].status = 'running'; now = true; }
        else if (ev.t === 'result') { Object.assign(tools[ev.id], { status: ev.ok ? 'ok' : 'fail', result: ev.d }); now = true; }
        else if (ev.t === 'error') throw new Error(ev.d);
        repaint(now);
      }
    }
  } catch (err) {
    if (err.name !== 'AbortError') { bot.error = true; bot.content = '⚠️ ' + err.message; }
    else lastText().text += '\n\n_(Detenido)_';
  }
  clearTimeout(timer);
  bot.parts.forEach(p => { if (p.type === 'tool' && !['ok', 'fail'].includes(p.status)) p.status = 'fail'; });
  bot.parts = bot.parts.filter(p => p.type !== 'text' || p.text.trim());
  if (!bot.error) bot.content = textOf(bot);
  bot.secs = Math.round((Date.now() - t0) / 1000);
  if (bot.thinking) bot.thinkSecs = Math.round(((tThinkEnd || Date.now()) - t0) / 1000);
  if (!bot.thinking) delete bot.thinking;
  ctrl = null; setSending(false);
  refreshCuenta();
  renderMessages();
  saveChat().catch(() => {});
}
function setSending(on) {
  const b = $('#btnSend'); b.classList.toggle('stop', on); b.textContent = on ? '■' : '↑'; b.title = on ? 'Detener' : 'Enviar (Enter)';
}
$('#btnSend').onclick = () => ctrl ? ctrl.abort() : sendMessage();
$('#input').addEventListener('keydown', e => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); sendMessage(); } });
function autosize() { const t = $('#input'); t.style.height = 'auto'; t.style.height = Math.min(t.scrollHeight, 240) + 'px'; }
$('#input').addEventListener('input', autosize);
document.querySelectorAll('.chip').forEach(c => c.onclick = () => {
  const p = plan(); if (p.models.includes(c.dataset.m)) { saveSettings({ model: c.dataset.m }); renderPickers(); }
  sendMessage(c.dataset.p);
});

// ---------- Imagenes ----------
// Archivos: las imágenes van a la IA si el modelo ve imágenes; todo lo demás se sube a la carpeta de trabajo
let pendingFiles = [];
$('#btnAttach').onclick = () => $('#file').click();
$('#file').onchange = async () => { await addFiles([...$('#file').files]); $('#file').value = ''; };
document.addEventListener('paste', async e => { const files = [...e.clipboardData.files]; if (files.length) { e.preventDefault(); await addFiles(files); } });
let dragN = 0;
addEventListener('dragenter', e => { if (e.dataTransfer?.types?.includes('Files')) { dragN++; $('#app').classList.add('dragging'); } });
addEventListener('dragleave', () => { if (--dragN <= 0) { dragN = 0; $('#app').classList.remove('dragging'); } });
addEventListener('dragover', e => e.preventDefault());
addEventListener('drop', async e => { e.preventDefault(); dragN = 0; $('#app').classList.remove('dragging'); if (e.dataTransfer?.files?.length) await addFiles([...e.dataTransfer.files]); });
async function addFiles(files) {
  for (const f of files) {
    const visionImg = f.type.startsWith('image/') && model().vision && f.size < 15e6;
    if (visionImg) pendingImgs.push(await toDataURL(f));
    // Se sube siempre a la carpeta de trabajo (así Nexo puede editarlo con herramientas)
    if (!visionImg || model().id === 'nexo-auto') {
      const chip = { nombre: f.name, subiendo: true }; pendingFiles.push(chip); renderAttachments();
      try {
        const r = await fetch('/api/subir?nombre=' + encodeURIComponent(f.name), { method: 'POST', body: f });
        Object.assign(chip, await r.json(), { subiendo: false });
      } catch { pendingFiles.splice(pendingFiles.indexOf(chip), 1); toast('No se pudo subir ' + f.name); }
    }
    renderAttachments();
  }
}
const toDataURL = f => new Promise(r => { const fr = new FileReader(); fr.onload = () => r(fr.result); fr.readAsDataURL(f); });
function renderAttachments() {
  $('#attachments').innerHTML = pendingImgs.map((s, i) => `<div class="att"><img src="${s}"><button data-i="${i}">✕</button></div>`).join('')
    + pendingFiles.map((f, i) => `<span class="fchip">📄 ${escapeHTML(f.nombre)}${f.subiendo ? ' · subiendo…' : ''}<button data-f="${i}">✕</button></span>`).join('');
  $('#attachments').querySelectorAll('button[data-i]').forEach(b => b.onclick = () => { pendingImgs.splice(+b.dataset.i, 1); renderAttachments(); });
  $('#attachments').querySelectorAll('button[data-f]').forEach(b => b.onclick = () => { pendingFiles.splice(+b.dataset.f, 1); renderAttachments(); });
}

// ---------- Memoria ----------
async function renderMemoria(list) {
  list = list || await api('/api/memoria');
  $('#memList').innerHTML = list.map((m, i) => `<div class="mem-item"><span>${escapeHTML(m)}</span><button data-i="${i}" title="Olvidar">✕</button></div>`).join('') || '<p class="note">Todavía no recuerda nada. Dile por ejemplo "recuerda que mi juego favorito es Fortnite".</p>';
  $('#memList').querySelectorAll('button').forEach(b => b.onclick = async () => renderMemoria(await api('/api/memoria', { method: 'POST', body: { remove: +b.dataset.i } })));
}
$('#memAddBtn').onclick = async () => { const v = $('#memNew').value.trim(); if (!v) return; $('#memNew').value = ''; renderMemoria(await api('/api/memoria', { method: 'POST', body: { add: v } })); toast('Nexo lo recordará'); };

// ---------- Barra lateral y ajustes ----------
$('#btnCollapse').onclick = () => $('#app').classList.add('collapsed');
$('#btnOpen').onclick = () => $('#app').classList.remove('collapsed');
$('#btnPlan').onclick = () => openModal('plans');
$('#btnClose').onclick = () => $('#modal').classList.add('hidden');
$('#modal').onclick = e => { if (e.target.id === 'modal') $('#modal').classList.add('hidden'); };
document.querySelectorAll('.tab').forEach(t => t.onclick = () => showTab(t.dataset.tab));
function showTab(name) {
  document.querySelectorAll('.tab').forEach(t => t.classList.toggle('active', t.dataset.tab === name));
  document.querySelectorAll('.tab-body').forEach(b => b.classList.toggle('hidden', b.id !== 'tab-' + name));
}
function openModal(tab) {
  renderPlans(); $('#setName').value = settings.userName || ''; $('#setSystem').value = settings.system || '';
  $('#setPermisos').value = settings.permisos || 'ask'; $('#setWorkspace').value = settings.workspace || '';
  $('#setWorkspace').placeholder = settings.workspaceDefault || '';
  renderMemoria();
  showTab(tab); $('#modal').classList.remove('hidden');
}
function renderPlans() {
  const own = cfg.cuenta?.propietario;
  if (cfg.cuenta?.demo) {   // Versión Demo: sin planes de pago
    const t = cfg.cuenta.tokens;
    $('#plans').innerHTML = `<div class="plan current" style="--pc:#4fd1ff;grid-column:1/-1">
      <h3>Nexo Demo</h3><div class="price">Gratis</div>
      <ul><li>${kfmt(t.limite)} tokens al día (hoy llevas ${kfmt(t.usados)}, te quedan ${kfmt(t.quedan)})</li><li>Nexo Auto, Nexo Chat y Nexo Code Rápido</li><li>Modo agente, 100 skills, memoria y subtítulos</li><li>Los tokens se recargan cada día a las 00:00</li></ul>
      <button disabled>Tu versión actual</button></div>
      <div class="lic-box" style="grid-column:1/-1"><h4>🚀 Versión completa: próximamente</h4><p class="note">Nexo Plus, Nexo Code 30B, Nexo Pro, Ultra Code y muchos más tokens llegarán con los planes de pago.</p></div>`;
    return;
  }
  $('#plans').innerHTML = cfg.plans.map(p => `<div class="plan ${p.id === settings.plan ? 'current' : ''}" style="--pc:${p.color}">
    <h3>${p.name}</h3><div class="price">${p.price} €<small>${p.price ? ' / mes' : ''}</small></div>
    <ul>${p.perks.map(x => `<li>${x}</li>`).join('')}</ul>
    <button data-plan="${p.id}">${p.id === settings.plan ? 'Tu plan actual' : own ? 'Cambiar a ' + p.name : 'Necesita licencia'}</button></div>`).join('')
    + `<div class="lic-box" style="grid-column:1/-1">${own
      ? `<h4>👑 Eres el propietario: tokens infinitos</h4><p class="note">Crea códigos de licencia para que otras personas desbloqueen un plan en su Nexo.</p>
         <div class="lic-row"><select id="licPlan"><option value="avanzado">Avanzado</option><option value="ultra">Ultra</option><option value="gratis">Gratis</option></select>
         <input id="licNombre" placeholder="Para quién (opcional)"><input id="licDias" type="number" min="0" placeholder="Días (0 = siempre)">
         <button class="primary" id="licGen">Crear licencia</button></div><textarea id="licOut" rows="2" readonly placeholder="Aquí aparecerá el código"></textarea>`
      : `<h4>🔑 Activar licencia</h4><p class="note">Pega el código que te han dado para desbloquear tu plan.${cfg.cuenta?.licencia ? ` Licencia actual: <b>${cfg.cuenta.licencia.plan}</b>${cfg.cuenta.licencia.caduca ? ' hasta el ' + new Date(cfg.cuenta.licencia.caduca).toLocaleDateString('es-ES') : ''}.` : ''}</p>
         <div class="lic-row"><input id="licCode" placeholder="NEXO-..."><button class="primary" id="licAct">Activar</button></div>`}</div>`;
  $('#plans').querySelectorAll('.plan button').forEach(b => b.onclick = async () => {
    if (b.dataset.plan === settings.plan) return;
    if (!own) { $('#licCode')?.focus(); return toast('Pega tu código de licencia abajo'); }
    await api('/api/settings', { method: 'POST', body: { plan: b.dataset.plan } });
    await loadConfig(); renderPlans(); toast('Plan ' + plan().name + ' activado');
  });
  $('#licGen') && ($('#licGen').onclick = async () => {
    const r = await api('/api/licencia', { method: 'POST', body: { generar: $('#licPlan').value, nombre: $('#licNombre').value, dias: +$('#licDias').value || 0 } });
    $('#licOut').value = r.codigo; $('#licOut').select(); navigator.clipboard.writeText(r.codigo).catch(() => {}); toast('Licencia creada y copiada');
  });
  $('#licAct') && ($('#licAct').onclick = async () => {
    try { const r = await api('/api/licencia', { method: 'POST', body: { codigo: $('#licCode').value } }); await loadConfig(); renderPlans(); toast('¡Plan ' + r.plan + ' activado!'); }
    catch (err) { toast(err.message); }
  });
}
$('#btnSaveProfile').onclick = () => {
  saveSettings({ userName: $('#setName').value.trim(), system: $('#setSystem').value.trim() });
  renderSide(); $('#modal').classList.add('hidden'); toast('Perfil guardado');
};
document.addEventListener('keydown', e => { if (e.key === 'Escape') { closeMenus(); $('#modal').classList.add('hidden'); } });

// ---------- Actualizaciones: si el servidor se ha actualizado, recargar la ventana ----------
let versionVista = null;
setInterval(async () => {
  try {
    const v = await api('/api/version');
    if (versionVista && v.local !== versionVista) { toast('✨ Nexo se ha actualizado a la versión ' + v.local); setTimeout(() => location.reload(), 1500); }
    versionVista = v.local;
  } catch {}
}, 15000);

// ---------- Paneles: Buscar, Creaciones, Skills ----------
function openPanel(title, html) { $('#panelTitle').textContent = title; $('#panelBody').innerHTML = html; $('#panel').classList.remove('hidden'); }
const closePanel = () => { $('#panel').classList.add('hidden'); $('#panelBody').innerHTML = ''; };
$('#panelClose').onclick = closePanel;
$('#panel').onclick = e => { if (e.target.id === 'panel') closePanel(); };

function openSearch() {
  openPanel('Buscar en tus chats', '<input class="search-input" id="sq" placeholder="Escribe para buscar en títulos y mensajes…" autocomplete="off"><div id="sres"></div>');
  const q = $('#sq'); q.focus(); let t;
  const run = async () => {
    const v = q.value.trim();
    if (!v) { $('#sres').innerHTML = chatCache.slice(0, 12).map(c => `<div class="res" data-id="${c.id}"><div class="rt">${escapeHTML(c.title)}</div><div class="rs">${new Date(c.updated).toLocaleString('es-ES')}</div></div>`).join(''); return; }
    const r = await api('/api/search?q=' + encodeURIComponent(v));
    $('#sres').innerHTML = r.map(c => `<div class="res" data-id="${c.id}"><div class="rt">${escapeHTML(c.title)}</div><div class="rs">${escapeHTML(c.snip)}</div></div>`).join('') || '<p class="note">Sin resultados.</p>';
  };
  q.oninput = () => { clearTimeout(t); t = setTimeout(run, 150); }; run();
  $('#sres').onclick = e => { const r = e.target.closest('.res'); if (r) { closePanel(); openChat(r.dataset.id); } };
}
$('#navSearch').onclick = openSearch;

const KIND_ICON = { video: '🎬', imagen: '🖼️', audio: '🎵', exe: '📦', web: '🌐', codigo: '📝', archivo: '📄' };
const fileURL = rel => '/files/' + rel.split(/[\\/]/).map(encodeURIComponent).join('/');
const fmtSize = b => b > 1e6 ? (b / 1e6).toFixed(1) + ' MB' : Math.max(1, Math.round(b / 1024)) + ' KB';
async function openCreations(filter = 'todo') {
  const { ws, files } = await api('/api/creaciones');
  const kinds = ['todo', 'web', 'video', 'imagen', 'exe', 'codigo', 'audio', 'archivo'];
  const names = { todo: 'Todo', web: 'Webs y juegos', video: 'Vídeos', imagen: 'Imágenes', exe: 'Programas', codigo: 'Código', audio: 'Audio', archivo: 'Otros' };
  const list = files.filter(f => filter === 'todo' || f.kind === filter);
  openPanel('Creaciones de Nexo', `<p class="note">Todo lo que Nexo crea en tu carpeta de trabajo: <code>${escapeHTML(ws)}</code></p>
    <div class="filters">${kinds.map(k => `<button data-k="${k}" class="${k === filter ? 'active' : ''}">${names[k]}</button>`).join('')}</div>
    <div id="prev"></div>
    <div class="grid-files">${list.map(f => `<div class="fcard" data-rel="${escapeHTML(f.rel)}" data-kind="${f.kind}">
      <div class="thumb">${f.kind === 'imagen' ? `<img loading="lazy" src="${fileURL(f.rel)}">` : f.kind === 'video' ? `<video muted preload="metadata" src="${fileURL(f.rel)}#t=1"></video>` : KIND_ICON[f.kind]}</div>
      <div class="fi"><div class="fn" title="${escapeHTML(f.rel)}">${escapeHTML(f.name)}</div><div class="fm">${fmtSize(f.size)} · ${new Date(f.mtime).toLocaleDateString('es-ES')}</div></div>
      <div class="fa">${f.kind !== 'exe' ? '<button data-a="ver">Ver</button>' : ''}<button data-a="abrir">Abrir</button><button data-a="carpeta">Carpeta</button></div></div>`).join('') || '<p class="note">Todavía no hay nada. ¡Pídele a Nexo que cree algo!</p>'}</div>`);
  $('#panelBody').onclick = async e => {
    const fb = e.target.closest('.filters button'); if (fb) return openCreations(fb.dataset.k);
    const card = e.target.closest('.fcard'); if (!card) return;
    const rel = card.dataset.rel, kind = card.dataset.kind;
    const a = e.target.closest('button')?.dataset.a || (e.target.closest('.thumb') && kind !== 'exe' ? 'ver' : null);
    if (a === 'abrir' || a === 'carpeta') { await api('/api/abrir', { method: 'POST', body: { ruta: rel, carpeta: a === 'carpeta' } }); toast(a === 'abrir' ? 'Abriendo…' : 'Abriendo carpeta…'); }
    if (a === 'ver') {
      const u = fileURL(rel);
      let inner = kind === 'imagen' ? `<img src="${u}">` : kind === 'video' ? `<video controls autoplay src="${u}"></video>` : kind === 'audio' ? `<audio controls autoplay src="${u}" style="width:100%;margin:20px 0"></audio>`
        : kind === 'web' ? `<iframe src="${u}" allow="autoplay; fullscreen"></iframe>` : `<pre>${escapeHTML(await (await fetch(u)).text())}</pre>`;
      $('#prev').innerHTML = `<div class="preview"><div class="preview-bar"><span>${escapeHTML(rel)}</span><button id="pvAbrir">Abrir fuera</button><button id="pvCerrar">✕</button></div>${inner}</div>`;
      $('#pvCerrar').onclick = () => $('#prev').innerHTML = '';
      $('#pvAbrir').onclick = () => api('/api/abrir', { method: 'POST', body: { ruta: rel } });
      $('#prev').scrollIntoView({ behavior: 'smooth' });
    }
  };
}
$('#navCreations').onclick = () => openCreations();

async function openSkills() {
  const skills = await api('/api/skills');
  const cats = [...new Set(skills.map(s => s.cat))];
  const on = skills.filter(s => s.on).length;
  openPanel(`Skills de Nexo (${on}/${skills.length} activas)`, `<p class="note">Las skills son conocimientos expertos. Nexo elige solo las que encajan con cada mensaje (máx. 3) y las aplica. Desactiva las que no quieras o crea las tuyas.</p>
    <input class="search-input" id="skq" placeholder="Buscar skill…">
    <div id="sklist">${cats.map(c => `<div class="skill-cat" data-cat="${escapeHTML(c)}">${escapeHTML(c)}</div><div class="skill-grid">${skills.filter(s => s.cat === c).map(s =>
      `<label class="skill ${s.on ? '' : 'off'}" data-n="${escapeHTML(s.name)}" data-k="${escapeHTML(s.claves.join(' '))}"><input type="checkbox" ${s.on ? 'checked' : ''}><div><div class="sn">${escapeHTML(s.name)}</div><div class="sk">${escapeHTML(s.claves.slice(0, 5).join(', '))}</div></div></label>`).join('')}</div>`).join('')}</div>
    <div class="skill-cat">＋ Crear una skill nueva</div>
    <div class="skill-new"><input id="nsName" placeholder="Nombre (ej: mi-estilo-miniaturas)"><input id="nsKeys" placeholder="Palabras clave separadas por comas (ej: miniatura, thumbnail)">
      <textarea id="nsBody" rows="5" placeholder="Instrucciones: qué debe saber o hacer Nexo cuando aparezcan esas palabras"></textarea><button class="primary" id="nsSave">Guardar skill</button></div>`);
  $('#sklist').onchange = async e => {
    const l = e.target.closest('.skill'); if (!l) return; l.classList.toggle('off', !e.target.checked);
    await api('/api/skills', { method: 'POST', body: { toggle: l.dataset.n, on: e.target.checked } });
  };
  $('#skq').oninput = () => {
    const q = $('#skq').value.toLowerCase();
    document.querySelectorAll('#sklist .skill').forEach(l => l.style.display = !q || (l.dataset.n + ' ' + l.dataset.k).includes(q) ? '' : 'none');
  };
  $('#nsSave').onclick = async () => {
    try { const r = await api('/api/skills', { method: 'POST', body: { name: $('#nsName').value, claves: $('#nsKeys').value, body: $('#nsBody').value } }); toast('Skill "' + r.name + '" creada'); openSkills(); }
    catch (err) { toast(err.message); }
  };
}
$('#navSkills').onclick = openSkills;

document.addEventListener('keydown', e => {
  if (e.ctrlKey && !e.altKey && e.key.toLowerCase() === 'k') { e.preventDefault(); openSearch(); }
  if (e.ctrlKey && e.altKey && e.key.toLowerCase() === 'n') { e.preventDefault(); newChat(); }
  if (e.key === 'Escape') { closePanel(); $('#ctxMenu').classList.add('hidden'); }
});

// ---------- Inicio ----------
(async () => {
  if (innerWidth < 760) $('#app').classList.add('collapsed');
  await loadConfig(); renderMessages(); renderChatList(); $('#input').focus();
  setInterval(async () => { try { const c = await api('/api/config'); cfg.installed = c.installed; renderStatus(); renderPickers(); } catch {} }, 20000);
})();
