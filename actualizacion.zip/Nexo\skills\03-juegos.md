# Juegos 2D

## juego-html-base
claves: haz un juego, hazme un juego, crea un juego, programa un juego, programame un juego, un juego de, juego 2d, juego html, arcade, juego de navegador
Juego 2D en un solo `index.html` (funciona con doble clic):
- Si es un juego de esquivar/disparar/arcade: usa `usar_plantilla` con "juego-arcade.html" (menú, partículas, temblor, sonido, récord) y `rellenar_plantilla` con {"TITULO": "..."}. Después adapta colores (COL), jugador y enemigos con editar_archivo si el juego lo pide. Así sale pulido.
- Para otros juegos (snake, plataformas, puzzle...) escríbelo entero siguiendo estas reglas.
- `<canvas>` a pantalla completa, redimensionado en `resize` y con `devicePixelRatio`.
- Bucle con `requestAnimationFrame` y delta time: `const dt = Math.min((t - last) / 1000, 0.05)`; mueve todo en px/segundo.
- Estados: 'menu' → 'jugando' → 'gameover', con pantalla de inicio ("Pulsa ESPACIO") y de reinicio.
- Entrada: teclado (keydown/keyup en un objeto `keys`) y también ratón/táctil.
- Puntuación en pantalla y récord guardado en localStorage.
- Gráficos dibujados con formas (rect, arc, path) y colores con estilo; sin imágenes externas salvo que existan.
- Al terminar: crea el exe con la skill crear-exe si lo piden, y ábrelo.

## juego-plataformas
claves: plataformas, platformer, saltar, mario, salto
- Física: gravedad ~2000 px/s², salto con velocidad inicial -750 px/s, velocidad máxima horizontal.
- Coyote time (0,1 s) y buffer de salto (0,1 s) para que se sienta bien.
- Colisiones AABB resolviendo primero eje X y luego eje Y.
- Nivel definido como array de strings ("#" bloque, "o" moneda, "E" enemigo, "F" meta). Cámara que sigue al jugador con suavizado.

## juego-shooter
claves: shooter, disparos, naves, space, balas, top down
- Jugador rota hacia el ratón (`Math.atan2`). Balas con velocidad y vida limitada; recicla objetos (pool).
- Oleadas de enemigos que aumentan de dificultad. Colisión círculo-círculo.
- Feedback: screen shake breve, partículas al destruir, parpadeo al recibir daño, sonido con WebAudio.

## juego-puzzle
claves: puzzle, 2048, tetris, match 3, buscaminas, memoria, tres en raya, snake
- Lógica en una matriz separada del dibujo. Funciones puras para mover/comprobar.
- Animaciones de interpolación entre estados (lerp) para que no "salte".
- Botón de reiniciar y deshacer si tiene sentido.

## juego-feel
claves: que se sienta bien, juice, efectos, divertido, mejor juego
Game feel ("juice"):
- Partículas, screen shake (2-6 px, 0,15 s), squash & stretch del personaje, flash blanco al golpear.
- Pausa de impacto (hit stop 40-60 ms). Sonidos cortos generados con WebAudio (oscillator + gain envolvente).
- Música/sonidos con botón de silenciar. Transiciones de pantalla con fundido.

## juego-sprites-pixel
claves: pixel art, sprites, 8 bits, retro, pixeles
- `ctx.imageSmoothingEnabled = false` y escalar a múltiplos enteros.
- Sprites definidos como arrays de strings con paleta (".": transparente, "1": color1...) y dibujados a un canvas offscreen una vez.
- Animación por frames con temporizador (8-12 fps). Fuente: monospace en negrita o dibujada.

## juego-csharp-exe
claves: juego exe, juego de windows, ejecutable, c#, winforms
Juego nativo de Windows en C# (WinForms) compilado a .exe con csc (ver crear-exe-csharp):
- Clase `Form` con `DoubleBuffered = true`, `Timer` a 16 ms, dibujo en `OnPaint` con `e.Graphics`.
- Teclas con `KeyDown`/`KeyUp` guardadas en un `HashSet<Keys>`.
- Solo usar System, System.Drawing, System.Windows.Forms (vienen con Windows).

## juego-ia-enemigos
claves: enemigos, ia enemiga, perseguir, patrulla, jefe, boss
- Máquina de estados: patrullar → perseguir (si distancia < radio) → atacar → huir.
- Persecución con vector normalizado hacia el jugador; separación entre enemigos para que no se amontonen.
- Jefes con fases según la vida y patrones de ataque telegrafiados (aviso antes de atacar).

## juego-ui-menus
claves: menu, hud, interfaz del juego, vidas, barra de vida, pausa
- HUD: vida, puntos y nivel siempre visibles en esquinas. Barra de vida con fondo y borde.
- Pausa con ESC/P. Menú principal con Jugar, Controles, Récords.
- Texto con sombra o contorno para que se lea sobre cualquier fondo.

## juego-guardado-niveles
claves: niveles, guardar partida, progreso, nivel 2, desbloquear
- Niveles como datos (JSON o arrays) en vez de código repetido.
- Progreso en localStorage (`JSON.stringify`). Selector de niveles con bloqueados/completados y estrellas.
