// Herramientas de Nexo (modo agente): archivos, carpetas, comandos, video, web.
import fs from 'node:fs/promises';
import path from 'node:path';
import os from 'node:os';
import { spawn } from 'node:child_process';
import { pathToFileURL } from 'node:url';
import { readdirSync, existsSync } from 'node:fs';

const MAX_OUT = 12000;
const NEXO_ROOT = path.resolve(path.dirname(new URL(import.meta.url).pathname.replace(/^\/([A-Za-z]:)/, '$1')), '..');
const TOOLS = path.join(NEXO_ROOT, 'tools');
const MEMORIA = path.join(NEXO_ROOT, 'data', 'memoria.json');
export async function readMemoria() { try { return JSON.parse(await fs.readFile(MEMORIA, 'utf8')); } catch { return []; } }
export async function writeMemoria(list) { await fs.mkdir(path.dirname(MEMORIA), { recursive: true }); await fs.writeFile(MEMORIA, JSON.stringify(list, null, 1), 'utf8'); }
const PLANTILLAS = path.resolve(path.dirname(new URL(import.meta.url).pathname.replace(/^\/([A-Za-z]:)/, '$1')), '..', 'plantillas');
const clip = (s, n = MAX_OUT) => (s.length > n ? s.slice(0, n) + `\n…(recortado, ${s.length - n} caracteres más)` : s);

export function resolvePath(p, ws) {
  if (!p) return ws;
  p = String(p).replace(/^~(?=[\\/]|$)/, os.homedir());
  p = p.replace(/%USERPROFILE%|\$env:USERPROFILE|\$HOME/gi, os.homedir());
  return path.isAbsolute(p) ? path.normalize(p) : path.join(ws, p);
}
const inside = (p, dir) => { const r = path.relative(dir, p); return r === '' || (!r.startsWith('..') && !path.isAbsolute(r)); };

// Definicion para Ollama (formato OpenAI)
const fn = (name, description, properties, required = Object.keys(properties)) =>
  ({ type: 'function', function: { name, description, parameters: { type: 'object', properties, required } } });
const S = d => ({ type: 'string', description: d });

export const TOOL_DEFS = [
  fn('listar', 'Lista archivos y carpetas de una ruta. Con recursivo=true muestra también el contenido de las subcarpetas (árbol) en una sola llamada: úsalo en vez de listar carpeta por carpeta.',
    { ruta: S('Ruta de la carpeta (relativa al espacio de trabajo o absoluta)'), recursivo: { type: 'boolean', description: 'true para ver también las subcarpetas' } }, []),
  fn('leer_archivo', 'Lee el contenido de un archivo de texto.', { ruta: S('Ruta del archivo') }),
  fn('crear_carpeta', 'Crea una carpeta (y las carpetas intermedias que falten).', { ruta: S('Ruta de la carpeta a crear') }),
  fn('escribir_archivo', 'Crea o sobrescribe un archivo de texto con el contenido COMPLETO (código, html, txt, json, md...). Crea las carpetas que falten.', { ruta: S('Ruta del archivo'), contenido: S('Contenido completo del archivo') }),
  fn('editar_archivo', 'Reemplaza un fragmento exacto de un archivo por otro texto. El fragmento debe existir tal cual.', { ruta: S('Ruta del archivo'), buscar: S('Texto exacto a reemplazar'), reemplazar: S('Texto nuevo') }),
  fn('buscar_en_archivos', 'Busca un texto o expresión regular dentro de los archivos de una carpeta (como grep). Devuelve archivo:línea: texto. Ideal para encontrar dónde está una función, variable o error en un proyecto.',
    { texto: S('Texto o regex a buscar'), carpeta: S('Carpeta donde buscar (por defecto el espacio de trabajo)'), extensiones: S('Opcional, ej: ".js,.html,.py"') }, ['texto']),
  fn('mover','Mueve o renombra un archivo o carpeta.', { origen: S('Ruta actual'), destino: S('Ruta nueva') }),
  fn('borrar', 'Envía un archivo o carpeta a la Papelera de reciclaje.', { ruta: S('Ruta a borrar') }),
  fn('ejecutar', 'Ejecuta un comando de PowerShell en Windows y devuelve la salida. Sirve para casi todo: ffmpeg (vídeo/audio), node, npm, git, winget, abrir programas, etc. Tiempo máximo 10 minutos.', { comando: S('Comando de PowerShell'), carpeta: S('Carpeta donde ejecutarlo (opcional)') }, ['comando']),
  fn('abrir', 'Abre un archivo, carpeta o URL con el programa predeterminado de Windows (para enseñárselo al usuario).', { ruta: S('Ruta o URL') }),
  fn('buscar_web', 'Busca en internet (DuckDuckGo) y devuelve títulos, enlaces y resúmenes. Solo funciona si hay conexión.', { consulta: S('Qué buscar') }),
  fn('leer_web', 'Descarga una página web y devuelve su texto.', { url: S('URL completa') }),
  fn('crear_exe', 'Crea un .exe de Windows que abre un juego o app web (index.html) en su propia ventana, sin barra del navegador. Úsalo para convertir juegos/apps HTML en programas de doble clic.',
    { carpeta: S('Carpeta del juego/app que contiene el HTML'), nombre: S('Nombre del .exe sin extensión, ej: MiJuego'), html: S('Archivo HTML dentro de la carpeta (por defecto index.html)') }, ['carpeta', 'nombre']),
  fn('compilar_csharp', 'Compila un archivo C# (.cs) a un .exe nativo de Windows con el compilador incluido en Windows (C# 5, .NET Framework 4.8, WinForms y System.Drawing disponibles).',
    { archivo: S('Ruta del .cs'), salida: S('Ruta del .exe a crear (opcional)'), tipo: { type: 'string', enum: ['ventana', 'consola'], description: 'ventana (WinForms/juego) o consola' } }, ['archivo']),
  fn('probar_web', 'Prueba una página web o juego HTML en un navegador invisible: devuelve los errores de JavaScript de la consola y guarda una captura. Úsalo SIEMPRE después de crear o editar una web o juego, y corrige los errores que salgan.',
    { ruta: S('Ruta del archivo HTML') }),
  fn('usar_plantilla', 'Copia una plantilla profesional de Nexo (landing-creador.html, juego-arcade.html) a una ruta y devuelve la lista de huecos [[...]] que hay que rellenar.',
    { plantilla: S('Nombre de la plantilla, ej: landing-creador.html'), destino: S('Ruta del archivo a crear, ej: mi-web/index.html') }),
  fn('rellenar_plantilla', 'Rellena los huecos [[...]] de un archivo creado con usar_plantilla. "valores" es un objeto: clave = texto del hueco (sin corchetes, o su comienzo), valor = texto real. Usa la clave "color" para cambiar el color de marca (hex).',
    { ruta: S('Ruta del archivo'), valores: { type: 'object', description: 'Ej: {"NOMBRE": "neconex22", "TITULAR CORTO": "Gano partidas<br>y <em>pierdo</em> amigos", "color": "#ff4d2e"}' } }),
  fn('recordar', 'Guarda en tu memoria permanente un dato importante y duradero del usuario (gustos, proyectos, datos de su canal, cómo quiere las cosas). Lo recordarás en todos los chats futuros. Úsalo cuando te cuente algo así o te pida que lo recuerdes.',
    { dato: S('El dato, en una frase corta, ej: "Su color favorito para diseños es el verde lima"') }),
  fn('olvidar', 'Borra de tu memoria permanente los datos que contengan un texto.', { texto: S('Texto a buscar en los recuerdos que hay que borrar') }),
  fn('transcribir', 'Transcribe la voz de un vídeo o audio con IA (whisper, en la gráfica). Crea subtítulos .srt y el texto .txt junto al archivo. Úsalo para subtítulos automáticos, resumir lo que se dice o buscar momentos.',
    { ruta: S('Ruta del vídeo o audio'), idioma: S('Código de idioma (por defecto es)') }, ['ruta']),
  fn('plan', 'Muestra al usuario tu plan de trabajo como lista de tareas. Úsalo al empezar una tarea de varios pasos y vuelve a llamarlo para marcar el progreso.',
    { pasos: { type: 'array', items: { type: 'string' }, description: 'Lista de pasos cortos' }, completados: { type: 'number', description: 'Cuántos pasos están terminados (0 al empezar)' } }, ['pasos']),
];

const ICONS = { listar: '📂', leer_archivo: '📄', crear_carpeta: '📁', escribir_archivo: '✏️', editar_archivo: '🩹', mover: '🔀', borrar: '🗑️', ejecutar: '⚡', abrir: '🚀', buscar_web: '🌐', leer_web: '🌐', crear_exe: '📦', compilar_csharp: '🛠️', plan: '📋', probar_web: '🧪', usar_plantilla: '🎨', rellenar_plantilla: '🖊️', recordar: '🧠', olvidar: '🧹', transcribir: '🎙️', buscar_en_archivos: '🔎' };
export const toolIcon = n => ICONS[n] || '🔧';

// Necesita permiso? (segun modo y ruta)
export function needsApproval(name, args, ws, mode) {
  if (mode === 'auto') return false;
  if (['listar', 'leer_archivo', 'buscar_web', 'leer_web', 'plan', 'probar_web', 'recordar', 'olvidar', 'buscar_en_archivos'].includes(name)) return false;
  if (name === 'transcribir') return !inside(resolvePath(args.ruta, ws), ws);
  if (name === 'usar_plantilla') return !inside(resolvePath(args.destino, ws), ws);
  if (name === 'rellenar_plantilla') return !inside(resolvePath(args.ruta, ws), ws);
  if (name === 'crear_exe') return !inside(resolvePath(args.carpeta, ws), ws);
  if (name === 'compilar_csharp') return !inside(resolvePath(args.salida || args.archivo, ws), ws);
  if (['crear_carpeta', 'escribir_archivo', 'editar_archivo'].includes(name)) return !inside(resolvePath(args.ruta, ws), ws);
  if (name === 'mover') return !inside(resolvePath(args.origen, ws), ws) || !inside(resolvePath(args.destino, ws), ws);
  if (name === 'abrir') return false;
  return true; // borrar, ejecutar
}

// PATH con las herramientas portátiles de Nexo (Python) delante, para que "python" y "pip" sean los de nexo\tools
let PY_DIR = null;
function findPython() {
  if (PY_DIR !== null) return PY_DIR;
  PY_DIR = '';
  try {
    for (const d of readdirSync(path.join(TOOLS, 'python'), { withFileTypes: true })) {
      if (d.isDirectory() && d.name.startsWith('cpython') && existsSync(path.join(TOOLS, 'python', d.name, 'python.exe'))) { PY_DIR = path.join(TOOLS, 'python', d.name); break; }
    }
  } catch {}
  return PY_DIR;
}
function toolEnv() {
  const py = findPython();
  const extra = py ? [py, path.join(py, 'Scripts')] : [];
  return { ...process.env, PATH: [...extra, process.env.PATH || process.env.Path || ''].join(';'), PYTHONIOENCODING: 'utf-8', PYTHONUTF8: '1' };
}

function runPS(command, cwd, signal, timeoutMs = 600000) {
  return new Promise(resolve => {
    const pre = '[Console]::OutputEncoding=[Text.Encoding]::UTF8; $ProgressPreference="SilentlyContinue"; ';
    const child = spawn('powershell.exe', ['-NoProfile', '-NonInteractive', '-ExecutionPolicy', 'Bypass', '-Command', pre + command],
      { cwd, windowsHide: true, env: toolEnv() });
    let out = '';
    child.stdout.on('data', d => { out += d; });
    child.stderr.on('data', d => { out += d; });
    const kill = () => { try { spawn('taskkill', ['/PID', String(child.pid), '/T', '/F'], { windowsHide: true }); } catch {} };
    const t = setTimeout(() => { out += '\n(Tiempo agotado: proceso detenido)'; kill(); }, timeoutMs);
    signal?.addEventListener('abort', kill);
    child.on('close', code => { clearTimeout(t); resolve(`(código de salida ${code})\n` + clip(out.trim() || '(sin salida)')); });
    child.on('error', e => { clearTimeout(t); resolve('Error: ' + e.message); });
  });
}

// Edge sin ventana para probar webs
const EDGE = ['C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe', 'C:\\Program Files\\Microsoft\\Edge\\Application\\msedge.exe'];
async function edgeHeadless(args, signal) {
  let exe = null; for (const e of EDGE) { try { await fs.access(e); exe = e; break; } catch {} }
  if (!exe) throw new Error('No encuentro Microsoft Edge para probar la web');
  return new Promise(resolve => {
    const child = spawn(exe, args, { windowsHide: true });
    let out = ''; child.stdout.on('data', d => out += d); child.stderr.on('data', d => out += d);
    const t = setTimeout(() => child.kill(), 25000);
    signal?.addEventListener('abort', () => child.kill());
    child.on('close', () => { clearTimeout(t); resolve(out); });
    child.on('error', e => { clearTimeout(t); resolve('Error: ' + e.message); });
  });
}

// Compilador de C# incluido en Windows (.NET Framework 4.x)
const CSC = 'C:\\Windows\\Microsoft.NET\\Framework64\\v4.0.30319\\csc.exe';
function csc(src, exe, tipo, signal) {
  return new Promise(resolve => {
    const args = ['/nologo', '/optimize+', `/target:${tipo === 'consola' ? 'exe' : 'winexe'}`, `/out:${exe}`,
      '/r:System.dll', '/r:System.Drawing.dll', '/r:System.Windows.Forms.dll', '/r:System.Core.dll', src];
    const child = spawn(CSC, args, { windowsHide: true });
    let out = ''; child.stdout.on('data', d => out += d); child.stderr.on('data', d => out += d);
    signal?.addEventListener('abort', () => child.kill());
    child.on('close', code => resolve({ ok: code === 0, out: clip(out.trim()) }));
    child.on('error', e => resolve({ ok: false, out: e.message }));
  });
}
const LAUNCHER = `using System; using System.Diagnostics; using System.IO; using System.Windows.Forms;
class Lanzador {
  [STAThread] static void Main() {
    string dir = AppDomain.CurrentDomain.BaseDirectory;
    string html = Path.Combine(dir, "__HTML__");
    if (!File.Exists(html)) { MessageBox.Show("No encuentro " + html + "\\nEl .exe debe estar en la misma carpeta que el juego.", "__NAME__"); return; }
    string[] rutas = { @"C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe", @"C:\\Program Files\\Microsoft\\Edge\\Application\\msedge.exe" };
    string edge = null; foreach (string r in rutas) if (File.Exists(r)) { edge = r; break; }
    string url = new Uri(html).AbsoluteUri;
    string perfil = Path.Combine(Path.GetTempPath(), "__NAME__-app");
    if (edge != null) Process.Start(edge, "--app=\\"" + url + "\\" --user-data-dir=\\"" + perfil + "\\" --window-size=1280,800 --no-first-run --disable-features=Translate");
    else Process.Start(url);
  }
}`;

const htmlToText = h => h.replace(/<script[\s\S]*?<\/script>|<style[\s\S]*?<\/style>|<noscript[\s\S]*?<\/noscript>/gi, ' ')
  .replace(/<br\s*\/?>|<\/(p|div|li|h\d|tr)>/gi, '\n').replace(/<[^>]+>/g, ' ')
  .replace(/&nbsp;/g, ' ').replace(/&amp;/g, '&').replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&quot;/g, '"').replace(/&#39;/g, "'")
  .replace(/[ \t]+/g, ' ').replace(/\n\s*\n+/g, '\n\n').trim();

export async function runTool(name, args, ws, signal) {
  const P = p => resolvePath(p, ws);
  switch (name) {
    case 'listar': {
      const dir = P(args.ruta);
      if (args.recursivo === true || args.recursivo === 'true') {
        const lines = []; let count = 0;
        const walkT = async (d, pre, depth) => {
          const items = (await fs.readdir(d, { withFileTypes: true }).catch(() => [])).filter(i => i.name !== 'node_modules' && !i.name.startsWith('.'));
          items.sort((a, b) => (b.isDirectory() - a.isDirectory()) || a.name.localeCompare(b.name));
          for (const it of items) {
            if (++count > 400) return;
            if (it.isDirectory()) { lines.push(`${pre}[carpeta] ${it.name}/`); if (depth < 4) await walkT(path.join(d, it.name), pre + '  ', depth + 1); }
            else { let sz = ''; try { sz = ` (${((await fs.stat(path.join(d, it.name))).size / 1024).toFixed(1)} KB)`; } catch {} lines.push(`${pre}${it.name}${sz}`); }
          }
        };
        await walkT(dir, '', 0);
        return `${dir}\n` + (lines.join('\n') || '(vacía)') + (count > 400 ? '\n…(hay más)' : '');
      }
      const items = await fs.readdir(dir, { withFileTypes: true });
      const lines = [];
      for (const it of items.slice(0, 300)) {
        if (it.isDirectory()) lines.push(`[carpeta] ${it.name}`);
        else { let sz = ''; try { sz = ` (${((await fs.stat(path.join(dir, it.name))).size / 1024).toFixed(1)} KB)`; } catch {} lines.push(`${it.name}${sz}`); }
      }
      return `${dir}\n` + (lines.join('\n') || '(vacía)') + (items.length > 300 ? `\n…y ${items.length - 300} más` : '');
    }
    case 'leer_archivo': {
      const f = P(args.ruta); const st = await fs.stat(f);
      if (st.size > 2_000_000) return `El archivo pesa ${(st.size / 1e6).toFixed(1)} MB, demasiado para leerlo entero.`;
      return clip(await fs.readFile(f, 'utf8'), 30000);
    }
    case 'crear_carpeta': { const d = P(args.ruta); await fs.mkdir(d, { recursive: true }); return `Carpeta creada: ${d}`; }
    case 'escribir_archivo': {
      const f = P(args.ruta); await fs.mkdir(path.dirname(f), { recursive: true });
      await fs.writeFile(f, String(args.contenido ?? ''), 'utf8');
      return `Archivo guardado: ${f} (${Buffer.byteLength(String(args.contenido ?? ''))} bytes)`;
    }
    case 'editar_archivo': {
      const f = P(args.ruta); const txt = await fs.readFile(f, 'utf8');
      const n = txt.split(args.buscar).length - 1;
      if (n === 0) {
        // Plan B: comparar línea a línea ignorando espacios al principio/final (los modelos pequeños fallan con la sangría)
        const lines = txt.split(/\r?\n/), want = String(args.buscar).split(/\r?\n/).map(l => l.trim());
        while (want.length && !want[0]) want.shift(); while (want.length && !want[want.length - 1]) want.pop();
        const hits = [];
        for (let i = 0; i + want.length <= lines.length && want.length; i++) if (want.every((w, j) => lines[i + j].trim() === w)) hits.push(i);
        if (hits.length === 1) {
          const indent = (lines[hits[0]].match(/^\s*/) || [''])[0];
          const repl = String(args.reemplazar).split(/\r?\n/).map((l, j) => (j === 0 || !l.trim()) ? (j === 0 ? indent + l.trimStart() : l) : (/^\s/.test(l) ? l : indent + l));
          lines.splice(hits[0], want.length, ...repl);
          await fs.writeFile(f, lines.join(txt.includes('\r\n') ? '\r\n' : '\n'), 'utf8');
          return `Editado (coincidencia ignorando espacios, líneas ${hits[0] + 1}-${hits[0] + want.length}): ${f}`;
        }
        return hits.length > 1 ? `Error: el fragmento aparece ${hits.length} veces; da uno más largo y único.` : 'Error: no encontré ese texto en el archivo. Léelo primero con leer_archivo y copia el fragmento exacto.';
      }
      if (n > 1) return `Error: el texto aparece ${n} veces; da un fragmento más largo y único.`;
      await fs.writeFile(f, txt.replace(args.buscar, () => args.reemplazar), 'utf8'); return `Editado: ${f}`;
    }
    case 'buscar_en_archivos': {
      const dir = P(args.carpeta); let re;
      try { re = new RegExp(String(args.texto), 'i'); } catch { re = new RegExp(String(args.texto).replace(/[.*+?^${}()|[\]\\]/g, '\\$&'), 'i'); }
      const exts = String(args.extensiones || '').split(',').map(s => s.trim().toLowerCase()).filter(Boolean);
      const out = []; let files = 0;
      const walkS = async (d, depth) => {
        if (depth > 6 || out.length >= 80) return;
        for (const it of await fs.readdir(d, { withFileTypes: true }).catch(() => [])) {
          if (['node_modules', '.git', '__pycache__', 'dist', 'build'].includes(it.name)) continue;
          const full = path.join(d, it.name);
          if (it.isDirectory()) { await walkS(full, depth + 1); continue; }
          const ext = path.extname(it.name).toLowerCase();
          if (exts.length ? !exts.includes(ext) : !/\.(js|mjs|cjs|ts|tsx|jsx|html?|css|json|py|cs|lua|luau|md|txt|ps1|bat|java|c|cpp|h|go|rs|php|xml|yml|yaml|ini|cfg|srt)$/i.test(ext)) continue;
          const st = await fs.stat(full).catch(() => null); if (!st || st.size > 1_500_000) continue;
          files++;
          const lines = (await fs.readFile(full, 'utf8').catch(() => '')).split(/\r?\n/);
          lines.forEach((l, i) => { if (out.length < 80 && re.test(l)) out.push(`${path.relative(dir, full)}:${i + 1}: ${l.trim().slice(0, 200)}`); });
        }
      };
      await walkS(dir, 0);
      return out.length ? `${out.length} coincidencias en ${dir}:\n${out.join('\n')}` : `Sin coincidencias en ${files} archivos de ${dir}.`;
    }
    case 'mover': {
      const a = P(args.origen), b = P(args.destino); await fs.mkdir(path.dirname(b), { recursive: true });
      await fs.rename(a, b); return `Movido: ${a} → ${b}`;
    }
    case 'borrar': {
      const f = P(args.ruta); await fs.access(f);
      const cmd = `Add-Type -AssemblyName Microsoft.VisualBasic; $p='${f.replace(/'/g, "''")}'; if (Test-Path $p -PathType Container) { [Microsoft.VisualBasic.FileIO.FileSystem]::DeleteDirectory($p,'OnlyErrorDialogs','SendToRecycleBin') } else { [Microsoft.VisualBasic.FileIO.FileSystem]::DeleteFile($p,'OnlyErrorDialogs','SendToRecycleBin') }; 'Enviado a la Papelera: ' + $p`;
      return runPS(cmd, ws, signal, 60000);
    }
    case 'ejecutar': {
      const cwd = args.carpeta ? P(args.carpeta) : ws; await fs.mkdir(cwd, { recursive: true });
      return runPS(String(args.comando), cwd, signal);
    }
    case 'abrir': {
      const t = /^https?:\/\//i.test(args.ruta) ? args.ruta : P(args.ruta);
      spawn('explorer.exe', [t], { detached: true, windowsHide: true }).unref(); return `Abierto: ${t}`;
    }
    case 'buscar_web': {
      const r = await fetch('https://html.duckduckgo.com/html/?q=' + encodeURIComponent(args.consulta),
        { headers: { 'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) Nexo/1.0' }, signal: AbortSignal.timeout(15000) });
      const h = await r.text(); const res = [];
      const re = /<a[^>]+class="result__a"[^>]+href="([^"]+)"[^>]*>([\s\S]*?)<\/a>[\s\S]*?<a[^>]+class="result__snippet"[^>]*>([\s\S]*?)<\/a>/g;
      let m; while ((m = re.exec(h)) && res.length < 8) {
        let url = m[1]; const u = url.match(/uddg=([^&]+)/); if (u) url = decodeURIComponent(u[1]);
        res.push(`- ${htmlToText(m[2])}\n  ${url}\n  ${htmlToText(m[3])}`);
      }
      return res.join('\n') || 'Sin resultados (¿hay internet?).';
    }
    case 'leer_web': {
      const r = await fetch(args.url, { headers: { 'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) Nexo/1.0' }, signal: AbortSignal.timeout(20000) });
      return clip(htmlToText(await r.text()), 15000);
    }
    case 'probar_web': {
      const f = P(args.ruta); await fs.access(f);
      const shot = f.replace(/\.html?$/i, '') + '-captura.png';
      const r = await edgeHeadless(['--headless=new', '--disable-gpu', '--enable-logging=stderr', '--v=0', '--hide-scrollbars',
        '--window-size=1280,800', '--virtual-time-budget=3000', `--screenshot=${shot}`, `--user-data-dir=${path.join(os.tmpdir(), 'nexo-probar')}`, pathToFileURL(f).href], signal);
      const lines = r.split(/\r?\n/).filter(l => /:CONSOLE\(\d+\)\]/.test(l))
        .map(l => l.replace(/^\[[^\]]*\]\s*/, '').replace(/^"|", source:.*$/g, '')).slice(0, 25);
      const errs = lines.filter(l => /error|uncaught|exception|not defined|cannot read|is not a function|unexpected/i.test(l));
      let ok = false; try { await fs.access(shot); ok = true; } catch {}
      return (errs.length ? `Se encontraron ${errs.length} errores de JavaScript (corrígelos):\n${errs.join('\n')}` : 'Sin errores de JavaScript en la consola. La página carga bien.')
        + (lines.length > errs.length ? `\nOtros mensajes de consola:\n${lines.filter(l => !errs.includes(l)).slice(0, 8).join('\n')}` : '')
        + (ok ? `\nCaptura guardada: ${shot}` : '');
    }
    case 'usar_plantilla': {
      const name = path.basename(String(args.plantilla || ''));
      const src = path.join(PLANTILLAS, name);
      const disponibles = (await fs.readdir(PLANTILLAS).catch(() => [])).join(', ');
      try { await fs.access(src); } catch { return `Error: no existe la plantilla "${name}". Disponibles: ${disponibles}`; }
      const dst = P(args.destino); await fs.mkdir(path.dirname(dst), { recursive: true });
      const txt = await fs.readFile(src, 'utf8'); await fs.writeFile(dst, txt, 'utf8');
      const huecos = [...new Set(txt.match(/\[\[[\s\S]*?\]\]/g) || [])].map(h => h.slice(2, -2));
      return `Plantilla copiada en ${dst}. Ahora llama a rellenar_plantilla UNA vez con TODOS estos huecos (usa estos nombres exactos como claves):\n` + huecos.join(', ')
        + '\nReglas: textos reales, concretos y con personalidad sobre el tema. Si no sabes un enlace (URL_...) pon "#" y si no sabes un usuario pon el nombre del canal. NUNCA inventes URLs, cifras ni datos: si no los sabes, usa algo genérico pero creíble o "#". Añade "color" con un color de marca en hex.';
    }
    case 'rellenar_plantilla': {
      const f = P(args.ruta); let txt = await fs.readFile(f, 'utf8');
      let vals = args.valores || {}; if (typeof vals === 'string') { try { vals = JSON.parse(vals); } catch { vals = {}; } }
      const nk = s => String(s).replace(/<br>/gi, ' ').replace(/\s+/g, ' ').trim().toLowerCase();
      let n = 0;
      for (const [k, v] of Object.entries(vals)) {
        if (k.toLowerCase() === 'color' && /^#?[0-9a-f]{3,8}$/i.test(String(v))) { txt = txt.replace(/--brand:\s*#[0-9a-f]+/i, '--brand: ' + (String(v).startsWith('#') ? v : '#' + v)); n++; continue; }
        const key = nk(k.replace(/^\[\[|\]\]$/g, ''));
        let hit = 0;
        txt = txt.replace(/\[\[([\s\S]*?)\]\]/g, (m, inner) => nk(inner) === key ? (hit++, String(v)) : m);
        if (!hit) txt = txt.replace(/\[\[([\s\S]*?)\]\]/g, (m, inner) => {
          const ni = nk(inner);
          return (key.length >= 6 && ni.startsWith(key)) || (key.length >= 12 && ni.startsWith(key.slice(0, 12))) ? (hit++, String(v)) : m;
        });
        n += hit;
      }
      txt = txt.replace(/<title>([\s\S]*?)<\/title>/i, (m, t) => `<title>${t.replace(/<[^>]+>/g, ' ').replace(/\s+/g, ' ').trim()}</title>`);
      await fs.writeFile(f, txt, 'utf8');
      const quedan = [...new Set(txt.match(/\[\[[\s\S]*?\]\]/g) || [])];
      return `Rellenados ${n} huecos en ${f}.` + (quedan.length ? `\nFaltan ${quedan.length} huecos: rellénalos ya con rellenar_plantilla (si es un enlace que no sabes, pon "#"; no preguntes al usuario):\n` + quedan.map(h => '- ' + h.slice(2, -2).replace(/\s+/g, ' ')).join('\n') : '\nNo queda ningún hueco. Ahora prueba la página con probar_web.');
    }
    case 'recordar': {
      const dato = String(args.dato || '').replace(/\s+/g, ' ').trim().slice(0, 300);
      if (!dato) return 'Error: falta el dato.';
      const mem = await readMemoria();
      if (mem.some(m => m.toLowerCase() === dato.toLowerCase())) return 'Ya lo recordaba.';
      mem.push(dato); await writeMemoria(mem.slice(-200));
      return `Guardado en memoria: "${dato}"`;
    }
    case 'olvidar': {
      const q = String(args.texto || '').toLowerCase().trim(); if (!q) return 'Error: falta el texto.';
      const mem = await readMemoria(); const rest = mem.filter(m => !m.toLowerCase().includes(q));
      await writeMemoria(rest); return `Borrados ${mem.length - rest.length} recuerdos.`;
    }
    case 'transcribir': {
      const f = P(args.ruta); await fs.access(f);
      const exe = path.join(TOOLS, 'whisper', 'whisper-cli.exe'), model = path.join(TOOLS, 'whisper', 'ggml-small.bin'), vad = path.join(TOOLS, 'whisper', 'ggml-silero-v5.1.2.bin');
      try { await fs.access(exe); } catch { return 'Error: whisper no está instalado en nexo/tools/whisper.'; }
      const base = f.replace(/\.[^.\\/]+$/, '');
      const wav = path.join(os.tmpdir(), `nexo-${Date.now()}.wav`);
      const a = await runPS(`ffmpeg -y -v error -i "${f}" -vn -ac 1 -ar 16000 -c:a pcm_s16le "${wav}"`, path.dirname(f), signal, 600000);
      if (!/código de salida 0/.test(a)) return 'Error convirtiendo el audio:\n' + a;
      // Liberar la gráfica para whisper (el modelo de chat se vuelve a cargar solo después)
      try {
        const ps = await (await fetch('http://127.0.0.1:11434/api/ps')).json();
        await Promise.all((ps.models || []).map(m => fetch('http://127.0.0.1:11434/api/generate', { method: 'POST', body: JSON.stringify({ model: m.name, keep_alive: 0 }) })));
        await new Promise(r => setTimeout(r, 2000));
      } catch {}
      const r = await new Promise(resolve => {
        const child = spawn(exe, ['-m', model, '-f', wav, '-l', String(args.idioma || 'es'), '-mc', '0', '--vad', '-vm', vad, '-t', '6', '-osrt', '-otxt', '-of', base, '-np'], { windowsHide: true, cwd: path.join(TOOLS, 'whisper') });
        let out = ''; child.stdout.on('data', d => out += d); child.stderr.on('data', d => out += d);
        signal?.addEventListener('abort', () => child.kill());
        child.on('close', code => resolve({ code, out })); child.on('error', e => resolve({ code: -1, out: e.message }));
      });
      await fs.rm(wav, { force: true });
      if (r.code !== 0) return 'Error de whisper:\n' + clip(r.out, 3000);
      const txt = await fs.readFile(base + '.txt', 'utf8').catch(() => '');
      return `Transcripción lista:\n- Subtítulos: ${base}.srt\n- Texto: ${base}.txt\n\nTexto (inicio):\n${clip(txt.trim(), 4000)}`;
    }
    case 'plan': {
      const pasos = Array.isArray(args.pasos) ? args.pasos : String(args.pasos || '').split(/\n|;/).filter(Boolean);
      return `Plan actualizado (${Math.min(+args.completados || 0, pasos.length)}/${pasos.length} hechos). Sigue con el siguiente paso.`;
    }
    case 'crear_exe': {
      const dir = P(args.carpeta); const html = args.html || 'index.html';
      await fs.access(path.join(dir, html)).catch(() => { throw new Error(`No existe ${path.join(dir, html)}. Crea primero el HTML.`); });
      const name = String(args.nombre || 'MiApp').replace(/[^\w\- ]/g, '').trim() || 'MiApp';
      const cs = LAUNCHER.replace('__HTML__', html.replace(/\\/g, '\\\\').replace(/"/g, '')).replaceAll('__NAME__', name.replace(/\s/g, ''));
      const csFile = path.join(os.tmpdir(), `nexo-${Date.now()}.cs`);
      await fs.writeFile(csFile, cs, 'utf8');
      const exe = path.join(dir, name + '.exe');
      const r = await csc(csFile, exe, 'ventana', signal);
      await fs.rm(csFile, { force: true });
      return r.ok ? `Ejecutable creado: ${exe}\nAbre ${html} en su propia ventana (Edge en modo app). Debe quedarse en la misma carpeta que ${html}.` : 'Error compilando el lanzador:\n' + r.out;
    }
    case 'compilar_csharp': {
      const src = P(args.archivo); await fs.access(src);
      const exe = args.salida ? P(args.salida) : src.replace(/\.cs$/i, '') + '.exe';
      const r = await csc(src, exe, args.tipo === 'consola' ? 'consola' : 'ventana', signal);
      return r.ok ? `Compilado correctamente: ${exe}` : 'Error de compilación (corrígelo y vuelve a compilar):\n' + r.out;
    }
    default: return 'Herramienta desconocida: ' + name;
  }
}
