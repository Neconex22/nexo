// Modo juego: pausa Nexo, libera la grafica y baja la prioridad de Ollama.
import { execFile } from 'node:child_process';
import os from 'node:os';

const OLLAMA = process.env.OLLAMA_URL || 'http://127.0.0.1:11434';

// Juegos conocidos (+ cualquier juego Unreal "...-Shipping.exe")
const GAMES = {
  'fortniteclient-win64-shipping.exe': 'Fortnite', 'valorant-win64-shipping.exe': 'Valorant', 'robloxplayerbeta.exe': 'Roblox',
  'arkascended.exe': 'ARK Ascended', 'shootergame.exe': 'ARK', 'f1_25.exe': 'F1 25', 'f1_24.exe': 'F1 24', 'fc25.exe': 'EA FC 25', 'fc26.exe': 'EA FC 26',
  'cs2.exe': 'Counter-Strike 2', 'gta5.exe': 'GTA V', 'gta5_enhanced.exe': 'GTA V', 'rocketleague.exe': 'Rocket League',
  'r5apex.exe': 'Apex Legends', 'cod.exe': 'Call of Duty', 'overwatch.exe': 'Overwatch', 'leagueoflegends.exe': 'League of Legends',
  'minecraft.windows.exe': 'Minecraft', 'eldenring.exe': 'Elden Ring', 'cyberpunk2077.exe': 'Cyberpunk 2077',
};
// Procesos de launchers/overlays que NO son juegos
const IGNORE = /^(epicgameslauncher|epicwebhelper|eosoverlayrenderer|unrealcefsubprocess|crashreportclient|easyanticheat|unrealeditor|unrealtrace)/i;

export const state = { paused: false, reason: null, game: null, auto: true };
const active = new Set();               // AbortControllers de respuestas en curso
export const track = ac => { active.add(ac); return () => active.delete(ac); };

const sh = (file, args) => new Promise(r => execFile(file, args, { windowsHide: true, maxBuffer: 8 << 20 }, (e, out) => r(e ? '' : String(out))));

export async function unloadAll() {
  try {
    const ps = await (await fetch(OLLAMA + '/api/ps', { signal: AbortSignal.timeout(3000) })).json();
    await Promise.all((ps.models || []).map(m => fetch(OLLAMA + '/api/generate', { method: 'POST', body: JSON.stringify({ model: m.name, keep_alive: 0 }) }).catch(() => {})));
  } catch {}
}

export async function pause(reason = 'manual', game = null) {
  state.paused = true; state.reason = reason; state.game = game;
  for (const ac of active) ac.abort();
  await unloadAll();
  // Si algun proceso del motor se queda colgado, lo cerramos para liberar la grafica del todo
  setTimeout(() => { if (state.paused) execFile('taskkill', ['/F', '/IM', 'llama-server.exe'], { windowsHide: true }, () => {}); }, 2000);
}
export function resume() { state.paused = false; state.reason = null; state.game = null; }

async function detectGame() {
  const out = await sh('tasklist', ['/fo', 'csv', '/nh']);
  for (const line of out.split(/\r?\n/)) {
    const exe = (line.match(/^"([^"]+)"/) || [])[1]; if (!exe) continue;
    const k = exe.toLowerCase();
    if (GAMES[k]) return GAMES[k];
    if (/-win64-shipping\.exe$/i.test(k) && !IGNORE.test(k)) return exe.replace(/-Win64-Shipping\.exe$/i, '');
  }
  return null;
}

// Prioridad "por debajo de lo normal" para Ollama: los juegos siempre van primero.
async function lowerPriority() {
  await sh('powershell.exe', ['-NoProfile', '-Command',
    "Get-Process ollama*,llama* -ErrorAction SilentlyContinue | Where-Object { $_.PriorityClass -ne 'BelowNormal' } | ForEach-Object { try { $_.PriorityClass = 'BelowNormal' } catch {} }"]);
}

// 75% del PC: hilos de CPU que puede usar cada modelo
export const CPU_THREADS = Math.max(1, Math.floor(os.cpus().length * 0.75));

// Apagado automático mientras juegas: suelta la gráfica (descarga el modelo y cierra el motor)
// en cuanto detecta un juego, SIN avisos ni botones. Vuelve solo al cerrar el juego.
export function startWatcher(getOn) {
  const tick = async () => {
    try {
      const on = await getOn();
      const g = on ? await detectGame() : null;
      const antes = state.game; state.game = g;
      if (g) {
        // Solo suelta la gráfica si no estás usando Nexo en ese momento (no corta una respuesta a medias)
        if (active.size === 0) {
          await unloadAll();
          setTimeout(() => { if (state.game) execFile('taskkill', ['/F', '/IM', 'llama-server.exe'], { windowsHide: true }, () => {}); }, 1500);
        }
        if (!antes) console.log(`[Nexo] ${g} detectado: suelto la gráfica para que no te baje los FPS.`);
      } else {
        if (antes) console.log('[Nexo] Juego cerrado: Nexo vuelve a estar listo.');
        await lowerPriority();
      }
    } catch {}
  };
  tick(); setInterval(tick, 8000);
}
